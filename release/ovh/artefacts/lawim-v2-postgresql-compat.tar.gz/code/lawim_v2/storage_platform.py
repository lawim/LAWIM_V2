from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

from .storage_registry import (
    GoogleDriveConfigurationModel,
    StorageResource,
    StorageResourceRegistry,
    StorageRoutingPolicy,
    StorageSetupWizard,
    StorageUsageThresholds,
    build_default_google_drive_configurations,
    build_default_storage_resources,
)


class StorageProvider(Protocol):
    name: str
    kind: str
    quota_gb: int
    used_gb: int
    status: str

    def resolve_access(self, *, media_id: int, kind: str) -> dict[str, Any]: ...

    def sync(self, *, media_id: int, direction: str = "outbound") -> dict[str, Any]: ...


@dataclass(slots=True)
class StorageOrchestratorPolicy:
    default_provider: str = "local"
    temporary_access_ttl_seconds: int = 900
    allowed_kinds: tuple[str, ...] = ("image", "video", "audio", "document")
    bandwidth_limit_mbps: int = 100


@dataclass(slots=True)
class ProviderHealth:
    name: str
    status: str = "activation-ready"
    note: str = "activation health snapshot"


@dataclass(slots=True)
class DriveBalancingRule:
    name: str
    target_kind: str
    provider_name: str
    max_bytes_per_job: int = 50_000_000


@dataclass(slots=True)
class DriveAssignment:
    provider_name: str
    kind: str
    size_bytes: int
    reason: str


@dataclass(slots=True)
class DriveQuotaManager:
    quotas_gb: dict[str, int] = field(default_factory=lambda: {"drive-1": 1000, "drive-2": 1000, "drive-3": 1000, "drive-4": 1000, "drive-5": 1000, "drive-6": 1000, "drive-7": 1000, "drive-8": 1000, "drive-9": 1000, "drive-10": 1000})

    def assign_drive(self, *, kind: str, size_bytes: int, rule: DriveBalancingRule | None = None) -> DriveAssignment:
        provider_name = rule.provider_name if rule else "drive-1"
        return DriveAssignment(provider_name=provider_name, kind=kind, size_bytes=size_bytes, reason=rule.name if rule else "default")


@dataclass(slots=True)
class CompressionPolicy:
    level: str = "balanced"


@dataclass(slots=True)
class DeduplicationPolicy:
    enabled: bool = True


@dataclass(slots=True)
class BandwidthPolicy:
    limit_mbps: int = 100


@dataclass(slots=True)
class LifecycleStateMachine:
    states: tuple[str, ...] = ("hot", "warm", "cold", "archived")

    def transition(self, current_state: str, target_state: str) -> str:
        if current_state not in self.states or target_state not in self.states:
            raise ValueError("unsupported lifecycle state")
        if current_state == "archived" and target_state != "archived":
            raise ValueError("archived media cannot transition forward")
        return target_state

    def backup_state_for(self, lifecycle_state: str) -> str:
        mapping = {"hot": "fresh", "warm": "queued", "cold": "queued", "archived": "archived"}
        return mapping.get(lifecycle_state, "queued")


@dataclass(slots=True)
class BackupJob:
    media_id: int
    kind: str
    status: str = "scheduled"
    target_provider: str = "backup-center"
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass(slots=True)
class RestoreJob:
    media_id: int
    reason: str
    status: str = "queued"
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass(slots=True)
class SyncJob:
    media_id: int
    provider_name: str
    direction: str
    status: str = "queued"


@dataclass(slots=True)
class BackupCenter:
    backup_jobs: list[BackupJob] = field(default_factory=list)
    restore_jobs: list[RestoreJob] = field(default_factory=list)
    sync_jobs: list[SyncJob] = field(default_factory=list)
    alerts: list[str] = field(default_factory=list)

    def add_alert(self, message: str) -> None:
        self.alerts.append(message)


@dataclass(slots=True)
class BackupManager:
    backup_center: BackupCenter

    def create_backup_job(self, *, media_id: int, kind: str) -> BackupJob:
        job = BackupJob(media_id=media_id, kind=kind)
        self.backup_center.backup_jobs.append(job)
        return job

    def create_restore_job(self, *, media_id: int, reason: str) -> RestoreJob:
        job = RestoreJob(media_id=media_id, reason=reason)
        self.backup_center.restore_jobs.append(job)
        return job


@dataclass(slots=True)
class RestorationEngine:
    def build_restore_plan(self, *, media_id: int, reason: str) -> dict[str, Any]:
        return {
            "media_id": media_id,
            "reason": reason,
            "source": "backup-center",
            "status": "ready",
        }


@dataclass(slots=True)
class StorageOptimizer:
    compression: CompressionPolicy = field(default_factory=CompressionPolicy)
    deduplication: DeduplicationPolicy = field(default_factory=DeduplicationPolicy)
    bandwidth: BandwidthPolicy = field(default_factory=BandwidthPolicy)

    def plan(self, *, media_id: int, kind: str) -> dict[str, Any]:
        return {
            "media_id": media_id,
            "kind": kind,
            "compression": self.compression.level,
            "deduplication_enabled": self.deduplication.enabled,
            "bandwidth_limit_mbps": self.bandwidth.limit_mbps,
        }


@dataclass(slots=True)
class ConversationArchivePolicy:
    drive_target: str = "drive-5"
    fallback_drive_target: str = "drive-8"
    retention_days: int = 365
    use_thumbnails: bool = True
    allow_restore_preview: bool = True


@dataclass(slots=True)
class ConversationRestorePolicy:
    allow_mock_restore: bool = True
    require_media_id: bool = True

    @property
    def allow_restore_preview(self) -> bool:
        return self.allow_mock_restore


@dataclass(slots=True)
class SetupWizardConfiguration:
    architecture: str
    backup_center_enabled: bool
    external_disk_enabled: bool
    google_drive_count: int = 10
    placeholder_notes: tuple[str, ...] = ("activation configuration", "no secrets stored")


@dataclass(slots=True)
class LocalStorageProvider:
    name: str = "local"
    kind: str = "local"
    quota_gb: int = 1000
    used_gb: int = 0
    status: str = "activation-ready"

    def resolve_access(self, *, media_id: int, kind: str) -> dict[str, Any]:
        return {
            "media_id": media_id,
            "kind": kind,
            "provider": self.name,
            "temporary_access_url": f"https://access.placeholder.lawim.invalid/{self.name}/{media_id}",
            "ttl_seconds": 900,
        }

    def sync(self, *, media_id: int, direction: str = "outbound") -> dict[str, Any]:
        return {"media_id": media_id, "provider": self.name, "direction": direction, "status": "activation-synced"}


@dataclass(slots=True)
class GoogleDriveProvider:
    name: str
    quota_gb: int = 1000
    used_gb: int = 0
    status: str = "activation-ready"
    kind: str = "google-drive"

    def resolve_access(self, *, media_id: int, kind: str) -> dict[str, Any]:
        return {
            "media_id": media_id,
            "kind": kind,
            "provider": self.name,
            "temporary_access_url": f"https://access.placeholder.lawim.invalid/{self.name}/{media_id}",
            "ttl_seconds": 900,
        }

    def sync(self, *, media_id: int, direction: str = "outbound") -> dict[str, Any]:
        return {"media_id": media_id, "provider": self.name, "direction": direction, "status": "activation-synced"}


@dataclass(slots=True)
class BackupCenterProvider:
    name: str = "backup-center"
    kind: str = "backup"
    quota_gb: int = 5000
    used_gb: int = 0
    status: str = "activation-ready"

    def resolve_access(self, *, media_id: int, kind: str) -> dict[str, Any]:
        return {"media_id": media_id, "kind": kind, "provider": self.name, "temporary_access_url": f"https://access.placeholder.lawim.invalid/{self.name}/{media_id}", "ttl_seconds": 900}

    def sync(self, *, media_id: int, direction: str = "outbound") -> dict[str, Any]:
        return {"media_id": media_id, "provider": self.name, "direction": direction, "status": "activation-synced"}


@dataclass(slots=True)
class ExternalDiskProvider:
    name: str
    capacity_gb: int = 200
    used_gb: int = 0
    status: str = "activation-ready"
    kind: str = "external-disk"

    def resolve_access(self, *, media_id: int, kind: str) -> dict[str, Any]:
        return {"media_id": media_id, "kind": kind, "provider": self.name, "temporary_access_url": f"https://access.placeholder.lawim.invalid/{self.name}/{media_id}", "ttl_seconds": 900}

    def sync(self, *, media_id: int, direction: str = "outbound") -> dict[str, Any]:
        return {"media_id": media_id, "provider": self.name, "direction": direction, "status": "activation-synced"}


@dataclass(slots=True)
class StorageOrchestrator:
    providers: list[StorageProvider]
    policy: StorageOrchestratorPolicy = field(default_factory=StorageOrchestratorPolicy)
    conversation_policy: ConversationArchivePolicy = field(default_factory=ConversationArchivePolicy)
    restore_policy: ConversationRestorePolicy = field(default_factory=ConversationRestorePolicy)
    resource_registry: StorageResourceRegistry = field(default_factory=StorageResourceRegistry.default)
    routing_policy: StorageRoutingPolicy = field(default_factory=StorageRoutingPolicy)

    def __post_init__(self) -> None:
        provider_names = {provider.name for provider in self.providers}
        if self.policy.default_provider not in provider_names:
            self.providers.append(LocalStorageProvider(name=self.policy.default_provider))

    def resolve_media_access(self, *, media_id: int, kind: str, provider_name: str | None = None) -> dict[str, Any]:
        provider = next((item for item in self.providers if item.name == (provider_name or self.policy.default_provider)), None)
        if provider is None:
            raise ValueError("unknown provider")
        selected_resource = self.select_storage_resource(kind=kind)
        route_category = self.routing_policy.canonicalize(kind)
        resolved = provider.resolve_access(media_id=media_id, kind=kind)
        resolved["lifecycle_state"] = "hot"
        resolved["policy"] = {
            "temporary_access_ttl_seconds": self.policy.temporary_access_ttl_seconds,
            "bandwidth_limit_mbps": self.policy.bandwidth_limit_mbps,
        }
        resolved["storage_resource"] = selected_resource.as_dict(self.resource_registry.thresholds)
        resolved["routing"] = {
            "category": route_category,
            "route": list(self.routing_policy.route_for(kind)),
            "selected_drive_id": selected_resource.drive_id,
        }
        return resolved

    def register_provider(self, provider: StorageProvider) -> None:
        self.providers.append(provider)

    def select_storage_resource(self, *, kind: str, size_gb: float = 0.0) -> StorageResource:
        return self.resource_registry.select(category=kind, size_gb=size_gb, routing_policy=self.routing_policy)

    def resource_snapshot(self) -> dict[str, Any]:
        return self.resource_registry.dashboard_snapshot()

    def resolve_conversation_archive_access(self, *, conversation_id: int, kind: str = "conversation_archive") -> dict[str, Any]:
        selected_resource = self.select_storage_resource(kind="conversation archive")
        return {
            "conversation_id": conversation_id,
            "kind": kind,
            "provider": selected_resource.drive_id,
            "fallback_provider": self.conversation_policy.fallback_drive_target,
            "temporary_access_url": f"https://access.placeholder.lawim.invalid/{selected_resource.drive_id}/{conversation_id}",
            "ttl_seconds": self.policy.temporary_access_ttl_seconds,
            "policy": {
                "drive_target": self.conversation_policy.drive_target,
                "fallback_drive_target": self.conversation_policy.fallback_drive_target,
                "retention_days": self.conversation_policy.retention_days,
                "use_thumbnails": self.conversation_policy.use_thumbnails,
                "allow_restore_preview": self.conversation_policy.allow_restore_preview,
                "require_media_id": self.restore_policy.require_media_id,
            },
            "routing": {
                "category": "conversation archive",
                "route": list(self.routing_policy.route_for("conversation archive")),
                "selected_drive_id": selected_resource.drive_id,
            },
            "storage_resource": selected_resource.as_dict(self.resource_registry.thresholds),
        }


__all__ = [
    "BackupCenter",
    "BackupCenterProvider",
    "ConversationArchivePolicy",
    "ConversationRestorePolicy",
    "BackupJob",
    "BackupManager",
    "BandwidthPolicy",
    "CompressionPolicy",
    "DeduplicationPolicy",
    "DriveAssignment",
    "DriveBalancingRule",
    "DriveQuotaManager",
    "ExternalDiskProvider",
    "GoogleDriveConfigurationModel",
    "GoogleDriveProvider",
    "LifecycleStateMachine",
    "LocalStorageProvider",
    "ProviderHealth",
    "RestoreJob",
    "RestorationEngine",
    "SetupWizardConfiguration",
    "StorageResource",
    "StorageResourceRegistry",
    "StorageRoutingPolicy",
    "StorageSetupWizard",
    "StorageUsageThresholds",
    "StorageOptimizer",
    "StorageOrchestrator",
    "StorageOrchestratorPolicy",
    "StorageProvider",
    "SyncJob",
]
