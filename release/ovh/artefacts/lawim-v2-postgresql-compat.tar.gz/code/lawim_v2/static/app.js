const state = {
  token: localStorage.getItem("lawim.token") || "",
  bootstrap: null,
  health: null,
  activeJourney: localStorage.getItem("lawim.journey") || "user",
  language: localStorage.getItem("lawim.language") || "fr",
  statsPeriod: localStorage.getItem("lawim.stats.period") || "today",
  selectedConversationId: null,
  selectedPropertyId: null,
  selectedPropertyVersion: null,
  selectedPropertyTitle: null,
  selectedProjectId: null,
  selectedSourceIntelligenceId: null,
  sourceIntelligenceDashboard: null,
  assistantSessionId: null,
  refreshInFlight: false,
};

const refs = {};
const moneyFormatter = new Intl.NumberFormat("fr-FR", {
  maximumFractionDigits: 0,
});
const ACCESS_ROLE_PRIORITY = ["admin", "manager", "operator", "partner", "user"];
const ROLE_LABELS = {
  admin: "Administrateur LAWIM",
  manager: "Manager",
  operator: "Opérateur LAWIM",
  partner: "Partenaire",
  user: "Utilisateur",
};
const ROLE_EMOJIS = {
  admin: "🛡️",
  manager: "📋",
  operator: "⚙️",
  partner: "🤝",
  user: "🏠",
};
const ROLE_JOURNEY_KEYS = {
  admin: ["admin", "project", "buyer", "seller"],
  manager: ["project", "buyer"],
  operator: ["seller", "project"],
  partner: ["project", "buyer"],
  user: ["buyer", "project"],
};
const ROLE_ALIASES = {
  admin: "admin",
  administrator: "admin",
  superadmin: "admin",
  director: "admin",
  root: "admin",
  manager: "manager",
  supervisor: "manager",
  lead: "manager",
  coordinator: "manager",
  operator: "operator",
  agent: "operator",
  staff: "operator",
  support: "operator",
  moderator: "operator",
  partner: "partner",
  photographer: "partner",
  notary: "partner",
  bank: "partner",
  artisan: "partner",
  architect: "partner",
  diagnostician: "partner",
  decorator: "partner",
  mover: "partner",
  broker: "partner",
  user: "user",
  owner: "user",
  buyer: "user",
  seller: "user",
  tenant: "user",
  landlord: "user",
  investor: "user",
  promoter: "user",
  customer: "user",
  viewer: "user",
  company: "user",
  enterprise: "user",
  business: "user",
  particulier: "user",
  private: "user",
  requester: "user",
};

const UI_COPY = {
  fr: {
    welcome: "Bonjour",
    loginTitle: "Connexion",
    loginLead: "Email et mot de passe uniquement. Aucun choix de rôle.",
    authenticated: "Déconnexion",
    activity: "Activité du jour",
    priorities: "Mes priorités",
    quickActions: "Mes actions rapides",
    statistics: "Mes statistiques",
    recommendations: "Recommandations IA",
    next: "Et maintenant ?",
    support: "Nous écrire",
    session: "Session invitée",
    selectRole: "Cockpit sélectionné",
    supportHint: "Suggestion, support, réclamation, signalement, partenariat ou autre demande.",
  },
  en: {
    welcome: "Hello",
    loginTitle: "Sign in",
    loginLead: "Email and password only. No role picker.",
    authenticated: "Sign out",
    activity: "Today's activity",
    priorities: "My priorities",
    quickActions: "Quick actions",
    statistics: "My statistics",
    recommendations: "AI recommendations",
    next: "What next?",
    support: "Write to us",
    session: "Guest session",
    selectRole: "Cockpit selected",
    supportHint: "Suggestion, support, complaint, report, partnership or other request.",
  },
  pidgin: {
    welcome: "Hallo",
    loginTitle: "Enter",
    loginLead: "Email and password only. No role choice.",
    authenticated: "Comot",
    activity: "Today activity",
    priorities: "My priorities",
    quickActions: "Quick actions",
    statistics: "My stats",
    recommendations: "AI recommendations",
    next: "Wetin next?",
    support: "Write us",
    session: "Guest session",
    selectRole: "Cockpit selected",
    supportHint: "Suggestion, support, complaint, report, partnership or other request.",
  },
};

const ROLE_COCKPIT_CONFIG = {
  admin: {
    subtitle: "Supervision complète de la plateforme et des releases.",
    activity: ["Suivi des utilisateurs", "Santé du runtime", "Préparation des releases"],
    priorities: ["Vérifier les accès", "Surveiller les métriques", "Piloter les comptes internes"],
    quickActions: [
      { label: "Créer une organisation", href: "#admin-org-form" },
      { label: "Créer un utilisateur", href: "#admin-user-form" },
      { label: "Ouvrir les métriques", href: "#admin-dashboard" },
      { label: "Nous écrire", href: "#message-form" },
    ],
    recommendations: ["Sécuriser les accès sensibles", "Contrôler les validations en attente", "Préparer le prochain déploiement"],
    nextActions: ["Planifier la revue opérationnelle", "Ouvrir les alertes prioritaires", "Valider les nouveaux comptes"],
    support: ["Suggestion", "Support", "Réclamation", "Signalement", "Partenariat", "Autre demande"],
  },
  manager: {
    subtitle: "Pilotage opérationnel, équipes et priorités du jour.",
    activity: ["Suivi des projets", "Validation des dossiers", "Communication d'équipe"],
    priorities: ["Relancer les dossiers bloqués", "Valider les étapes critiques", "Répartir les actions rapides"],
    quickActions: [
      { label: "Voir les projets", href: "#projects-list" },
      { label: "Suivre les conversations", href: "#conversations-list" },
      { label: "Consulter les statistiques", href: "#status-strip" },
      { label: "Nous écrire", href: "#message-form" },
    ],
    recommendations: ["Clarifier les étapes en retard", "Réduire les points de friction", "Renforcer les validations utiles"],
    nextActions: ["Rattraper les dossiers en cours", "Prioriser les validations", "Ouvrir le suivi des notifications"],
    support: ["Suggestion", "Support", "Réclamation", "Signalement", "Partenariat", "Autre demande"],
  },
  operator: {
    subtitle: "Gestion quotidienne, support et contrôle qualité.",
    activity: ["Biens à vérifier", "Photos et médias", "Messages en attente"],
    priorities: ["Contrôler les publications", "Mettre à jour les médias", "Répondre aux demandes"],
    quickActions: [
      { label: "Créer un bien", href: "#property-form" },
      { label: "Géolocaliser", href: "#geo-form" },
      { label: "Téléverser des médias", href: "#media-upload-form" },
      { label: "Nous écrire", href: "#message-form" },
    ],
    recommendations: ["Améliorer la qualité des annonces", "Vérifier les doublons de médias", "Traiter les retours clients"],
    nextActions: ["Publier un bien prêt", "Relancer un dossier", "Ouvrir le fil de conversation"],
    support: ["Suggestion", "Support", "Réclamation", "Signalement", "Partenariat", "Autre demande"],
  },
  partner: {
    subtitle: "Missions, rendez-vous et échanges liés à votre spécialité.",
    activity: ["Missions en cours", "Rendez-vous", "Documents partagés"],
    priorities: ["Confirmer les disponibilités", "Préparer les livrables", "Répondre aux sollicitations"],
    quickActions: [
      { label: "Voir les opportunités", href: "#matches-list" },
      { label: "Consulter les partenaires", href: "#partners-list" },
      { label: "Relire les biens", href: "#properties-list" },
      { label: "Nous écrire", href: "#message-form" },
    ],
    recommendations: ["Proposer une offre plus lisible", "Documenter les livrables", "Raccourcir le délai de réponse"],
    nextActions: ["Préparer le prochain rendez-vous", "Relancer une mission", "Ouvrir les messages"],
    support: ["Suggestion", "Support", "Réclamation", "Signalement", "Partenariat", "Autre demande"],
  },
  user: {
    subtitle: "Votre projet immobilier, vos priorités et les prochaines étapes.",
    activity: ["Recherche en cours", "Visites prévues", "Documents à compléter"],
    priorities: ["Comparer les biens", "Préparer les documents", "Suivre les notifications"],
    quickActions: [
      { label: "Rechercher un bien", href: "#property-search-form" },
      { label: "Créer un projet", href: "#project-form" },
      { label: "Démarrer une conversation", href: "#buyer-conversation-form" },
      { label: "Nous écrire", href: "#message-form" },
    ],
    recommendations: ["Activer les favoris utiles", "Planifier les visites", "Finaliser le dossier"],
    nextActions: ["Lancer une recherche ciblée", "Ouvrir la carte des biens", "Comparer les opportunités"],
    support: ["Suggestion", "Support", "Réclamation", "Signalement", "Partenariat", "Autre demande"],
  },
};

function byId(id) {
  return document.getElementById(id);
}

function shouldTraceAuth() {
  try {
    return window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" || localStorage.getItem("lawim.debug.auth") === "1";
  } catch {
    return false;
  }
}

function uiCopy() {
  return UI_COPY[state.language] || UI_COPY.fr;
}

function updateAuthShell(isAuthenticated) {
  document.body.dataset.authenticated = isAuthenticated ? "true" : "false";
  if (refs.workspace) {
    refs.workspace.hidden = !isAuthenticated;
  }
  if (refs.runtimeChip) {
    refs.runtimeChip.hidden = !isAuthenticated;
  }
  if (refs.currentUser) {
    refs.currentUser.hidden = !isAuthenticated;
  }
  if (refs.logoutButton) {
    refs.logoutButton.hidden = !isAuthenticated;
  }
}

function extractRoleValue(role) {
  if (typeof role === "string" || typeof role === "number") {
    return role;
  }
  if (role && typeof role === "object") {
    return role.role || role.role_key || role.key || role.name || "";
  }
  return "";
}

function normalizeAccessRole(role) {
  const normalized = String(extractRoleValue(role) || "").trim().toLowerCase();
  if (!normalized) {
    return "";
  }
  return ROLE_ALIASES[normalized] || "";
}

function resolveAccessRole(primaryRole, roles = []) {
  const direct = normalizeAccessRole(primaryRole);
  if (direct) {
    return direct;
  }
  const candidates = Array.isArray(roles) ? roles : [];
  for (const priority of ACCESS_ROLE_PRIORITY) {
    if (candidates.some((candidate) => normalizeAccessRole(candidate) === priority)) {
      return priority;
    }
  }
  return "user";
}

function journeyForRole(role) {
  return normalizeAccessRole(role) || "user";
}

function roleLabel(role) {
  const normalized = normalizeAccessRole(role);
  return ROLE_LABELS[normalized] || ROLE_LABELS.user;
}

function clearSession() {
  state.token = "";
  localStorage.removeItem("lawim.token");
  updateAuthShell(false);
  if (refs.currentUser) {
    refs.currentUser.textContent = uiCopy().session;
  }
  if (refs.logoutButton) {
    refs.logoutButton.disabled = true;
  }
  if (refs.roleCockpit) {
    refs.roleCockpit.hidden = true;
  }
  if (refs.loginPassword) {
    refs.loginPassword.value = "";
  }
}

function isServerUnavailableError(error) {
  const status = Number(error?.status || 0);
  return status >= 500 || (!status && /fetch|network|timeout|unavailable/i.test(String(error?.message || "")));
}

function formatLoginError(error) {
  const status = Number(error?.status || 0);
  if (status === 401) {
    return "Identifiants incorrects.";
  }
  if (status === 403) {
    return "Accès non autorisé.";
  }
  if (isServerUnavailableError(error)) {
    return "Serveur indisponible. Réessayez dans un instant.";
  }
  return error?.message || "Connexion impossible.";
}

function formatSessionError(error) {
  const status = Number(error?.status || 0);
  if (status === 401) {
    return { message: "Session expirée. Connectez-vous de nouveau.", tone: "warn", clearToken: true };
  }
  if (status === 403) {
    return { message: "Accès non autorisé.", tone: "warn", clearToken: true };
  }
  if (isServerUnavailableError(error)) {
    return { message: "Serveur indisponible. Réessayez dans un instant.", tone: "error", clearToken: false };
  }
  return { message: error?.message || "Impossible de restaurer la session.", tone: "error", clearToken: false };
}

function cacheRefs() {
  Object.assign(refs, {
    runtimeChip: byId("runtime-chip"),
    languageSelect: byId("language-select"),
    currentUser: byId("current-user"),
    workspace: byId("workspace"),
    notice: byId("notice"),
    bootstrapSummary: byId("bootstrap-summary"),
    statusStrip: byId("status-strip"),
    roleCockpit: byId("role-cockpit"),
    roleGreeting: byId("role-greeting"),
    roleSubtitle: byId("role-subtitle"),
    roleChip: byId("role-chip"),
    roleActivityChip: byId("role-activity-chip"),
    progressCard: byId("progress-card"),
    activityCard: byId("activity-card"),
    prioritiesCard: byId("priorities-card"),
    quickActionsCard: byId("quick-actions-card"),
    statsCard: byId("stats-card"),
    statsPeriodSelect: byId("stats-period-select"),
    recommendationsCard: byId("recommendations-card"),
    nextActionsCard: byId("next-actions-card"),
    supportCard: byId("support-card"),
    organizationsList: byId("organizations-list"),
    propertiesList: byId("properties-list"),
    mediaList: byId("media-list"),
    matchesList: byId("matches-list"),
    conversationsList: byId("conversations-list"),
    notificationsList: byId("notifications-list"),
    markNotificationsReadButton: byId("mark-notifications-read"),
    conversationDetail: byId("conversation-detail"),
    messageForm: byId("message-form"),
    loginForm: byId("login-form"),
    loginEmail: byId("login-email"),
    loginPassword: byId("login-password"),
    logoutButton: byId("logout-button"),
    matchForm: byId("match-form"),
    propertyForm: byId("property-form"),
    geoForm: byId("geo-form"),
    geoResult: byId("geo-result"),
    mediaUploadForm: byId("media-upload-form"),
    mediaPropertySelect: byId("media-property-select"),
    ownerOrganizationSelect: byId("owner-organization-select"),
    registerOrganizationSelect: byId("register-organization-select"),
    adminOrganizationSelect: byId("admin-organization-select"),
    journeyNav: byId("journey-nav"),
    registerForm: byId("register-form"),
    propertySearchForm: byId("property-search-form"),
    propertySearchMeta: byId("property-search-meta"),
    notificationFilterForm: byId("notification-filter-form"),
    notificationUnreadCount: byId("notification-unread-count"),
    negotiationForm: byId("negotiation-form"),
    buyerConversationForm: byId("buyer-conversation-form"),
    adminOrgForm: byId("admin-org-form"),
    adminUserForm: byId("admin-user-form"),
    adminDashboard: byId("admin-dashboard"),
    selectedPropertyLabel: byId("selected-property-label"),
    publishPropertyButton: byId("publish-property-button"),
    archivePropertyButton: byId("archive-property-button"),
    projectForm: byId("project-form"),
    projectsList: byId("projects-list"),
    projectDetail: byId("project-detail"),
    partnersList: byId("partners-list"),
    servicesList: byId("services-list"),
    assistantSummary: byId("assistant-summary"),
    assistantForm: byId("assistant-form"),
    assistantChat: byId("assistant-chat"),
    knowledgeAdminStats: byId("knowledge-admin-stats"),
    knowledgeAdminList: byId("knowledge-admin-list"),
    knowledgeSearchForm: byId("knowledge-search-form"),
    knowledgeSearchResults: byId("knowledge-search-results"),
    workflowAdminStats: byId("workflow-admin-stats"),
    workflowAdminList: byId("workflow-admin-list"),
    workflowMonitorForm: byId("workflow-monitor-form"),
    workflowMonitorResults: byId("workflow-monitor-results"),
    reiAdminStats: byId("rei-admin-stats"),
    reiAdminList: byId("rei-admin-list"),
    reiSearchForm: byId("rei-search-form"),
    reiSearchResults: byId("rei-search-results"),
    crmAdminStats: byId("crm-admin-stats"),
    crmAdminList: byId("crm-admin-list"),
    crmSearchForm: byId("crm-search-form"),
    crmSearchResults: byId("crm-search-results"),
    marketplaceAdminStats: byId("marketplace-admin-stats"),
    marketplaceAdminList: byId("marketplace-admin-list"),
    marketplaceSearchForm: byId("marketplace-search-form"),
    marketplaceSearchResults: byId("marketplace-search-results"),
    communicationAdminStats: byId("communication-admin-stats"),
    communicationAdminList: byId("communication-admin-list"),
    analyticsAdminStats: byId("analytics-admin-stats"),
    analyticsAdminList: byId("analytics-admin-list"),
    sieAdminStats: byId("sie-admin-stats"),
    sieAdminList: byId("sie-admin-list"),
    sieImportForm: byId("sie-import-form"),
    sieSourceForm: byId("sie-source-form"),
    sieReferenceForm: byId("sie-reference-form"),
    sieReferenceResult: byId("sie-reference-result"),
    sieLinkResult: byId("sie-link-result"),
    sieAnalyzeButton: byId("sie-analyze-button"),
    sieWhatsappButton: byId("sie-whatsapp-button"),
    securityAdminStats: byId("security-admin-stats"),
    securityAdminList: byId("security-admin-list"),
    securityAuditForm: byId("security-audit-form"),
    securityAuditResults: byId("security-audit-results"),
  });
}

function setNotice(message, tone = "neutral", code = "") {
  refs.notice.dataset.tone = tone;
  refs.notice.textContent = code ? `[${code}] ${message}` : message;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function setLoading(isLoading, message = "Loading...") {
  document.body.dataset.loading = isLoading ? "true" : "false";
  if (isLoading && refs.notice) {
    refs.notice.dataset.tone = "neutral";
    refs.notice.textContent = message;
  }
}

function traceRuntime(step, details = {}) {
  if (!shouldTraceAuth()) {
    return;
  }
  console.debug(step, details);
}

function formatApiError(payload, status) {
  const code = payload?.error?.code;
  const message = payload?.error?.message || payload?.message || `HTTP ${status}`;
  return { code: code || "", message };
}

function statusChipClass(status) {
  const normalized = String(status || "draft").toLowerCase();
  if (normalized === "published") {
    return "chip accent";
  }
  if (normalized === "archived") {
    return "chip subtle";
  }
  return "chip subtle";
}

function setRuntimeChip(message, tone = "neutral") {
  refs.runtimeChip.dataset.tone = tone;
  refs.runtimeChip.textContent = message;
}

function money(value, currency = "XAF") {
  if (value === null || value === undefined || value === "") {
    return "n/a";
  }
  const formatted = moneyFormatter.format(Number(value));
  return `${formatted} ${currency}`;
}

function propertyPrice(property) {
  if (property.price) {
    return {
      min: property.price.min,
      max: property.price.max,
      currency: property.price.currency || "XAF",
    };
  }
  return {
    min: property.price_min,
    max: property.price_max,
    currency: property.currency || "XAF",
  };
}

function propertyGeo(property) {
  if (property.geo) {
    return property.geo;
  }
  return {
    city: property.city,
    country: property.country,
    region: property.region,
    address_line: property.address_line,
    coordinates: { latitude: property.latitude, longitude: property.longitude },
  };
}

function requestHeaders(headers = {}, auth = false) {
  const merged = { ...headers };
  if (auth && state.token) {
    merged.Authorization = `Bearer ${state.token}`;
  }
  return merged;
}

async function api(path, { method = "GET", auth = false, body = null, query = null, headers = {} } = {}) {
  const url = new URL(path, window.location.origin);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && `${value}`.trim() !== "") {
        url.searchParams.set(key, String(value));
      }
    }
  }

  const response = await fetch(url, {
    method,
    headers: requestHeaders({ ...(body ? { "Content-Type": "application/json" } : {}), ...headers }, auth),
    body: body ? JSON.stringify(body) : undefined,
  });

  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error(`Invalid JSON response from ${path}`);
    }
  }

  if (!response.ok) {
    const formatted = formatApiError(payload, response.status);
    const error = new Error(formatted.message);
    error.code = formatted.code;
    error.status = response.status;
    error.payload = payload;
    throw error;
  }

  return payload;
}

async function apiMultipart(path, { auth = false, formData }) {
  const response = await fetch(path, {
    method: "POST",
    headers: requestHeaders({}, auth),
    body: formData,
  });
  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error(`Invalid JSON response from ${path}`);
    }
  }
  if (!response.ok) {
    const formatted = formatApiError(payload, response.status);
    const error = new Error(formatted.message);
    error.code = formatted.code;
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

function clearNode(node) {
  node.replaceChildren();
}

function renderStat(label, value, accent = "") {
  const item = document.createElement("article");
  item.className = "stat-card";
  if (accent) {
    item.dataset.accent = accent;
  }
  const statLabel = document.createElement("span");
  statLabel.className = "stat-label";
  statLabel.textContent = label;
  const statValue = document.createElement("strong");
  statValue.textContent = value;
  item.append(statLabel, statValue);
  return item;
}

function renderSummary(summary) {
  const fragment = document.createDocumentFragment();
  const cards = [
    ["🏢 Organisations", summary.organizations ?? 0, "teal"],
    ["👥 Utilisateurs", summary.users ?? 0, "gold"],
    ["🏠 Biens publiés", summary.published_properties ?? 0, "violet"],
    ["💬 Conversations", summary.conversations ?? 0, "coral"],
    ["✉️ Messages", summary.messages ?? 0, "sea"],
    ["🔔 Notifications", summary.notifications ?? 0, "gold"],
    ["🖼 Médias", summary.media ?? 0, "slate"],
    ["🚧 Projets", summary.projects ?? 0, "teal"],
  ];
  cards.forEach(([label, value, accent]) => fragment.appendChild(renderStat(label, value, accent)));
  refs.statusStrip?.replaceChildren(fragment);
}

function renderList(target, items, renderer, emptyText) {
  const fragment = document.createDocumentFragment();
  if (!items || !items.length) {
    const empty = document.createElement("p");
    empty.className = "muted empty-state";
    empty.textContent = emptyText;
    target.replaceChildren(empty);
    return;
  }
  items.forEach((item) => fragment.appendChild(renderer(item)));
  target.replaceChildren(fragment);
}

function renderPillList(items, emptyText) {
  if (!items.length) {
    return `<p class="muted empty-state">${escapeHtml(emptyText)}</p>`;
  }
  return `<div class="pill-list">${items.map((item) => `<span class="pill">${escapeHtml(item)}</span>`).join("")}</div>`;
}

function renderActionLinks(actions) {
  if (!actions.length) {
    return "<p class='muted empty-state'>—</p>";
  }
  return `<div class="action-link-grid">${actions
    .map(
      (action) => `<a class="button secondary action-link" href="${escapeHtml(action.href)}">${escapeHtml(action.label)}</a>`,
    )
    .join("")}</div>`;
}

function renderKeyValueRows(rows, emptyText) {
  if (!rows.length) {
    return `<p class="muted empty-state">${escapeHtml(emptyText)}</p>`;
  }
  return `<div class="cockpit-stack">${rows
    .map(
      (row) => `
        <article class="cockpit-row">
          <span class="cockpit-row__label">${escapeHtml(row.label)}</span>
          <strong>${escapeHtml(row.value)}</strong>
          <span class="muted">${escapeHtml(row.detail || "")}</span>
        </article>
      `,
    )
    .join("")}</div>`;
}

function pickPrimaryProject(items) {
  return (items || []).find((project) => project.status !== "archived") || (items || [])[0] || null;
}

function formatRoleStatus(role) {
  return `${ROLE_EMOJIS[role] || "✨"} ${roleLabel(role)}`;
}

function setLanguage(language) {
  const normalized = ["fr", "en", "pidgin"].includes(language) ? language : "fr";
  state.language = normalized;
  localStorage.setItem("lawim.language", normalized);
  document.documentElement.lang = normalized === "pidgin" ? "en" : normalized;
  if (refs.languageSelect && refs.languageSelect.value !== normalized) {
    refs.languageSelect.value = normalized;
  }
  if (state.bootstrap?.current_user) {
    renderRoleCockpit(state.bootstrap.current_user, state.bootstrap);
  }
}

function renderRoleCockpit(currentUser, payload) {
  if (!refs.roleCockpit || !refs.roleGreeting || !refs.progressCard || !refs.activityCard) {
    return;
  }

  const role = resolveAccessRole(currentUser?.role, currentUser?.roles || payload.roles || []);
  const config = ROLE_COCKPIT_CONFIG[role] || ROLE_COCKPIT_CONFIG.user;
  const summary = payload.summary || {};
  const projects = payload.projects || [];
  const conversations = payload.conversations || [];
  const notifications = payload.notifications || [];
  const matches = payload.matches || [];
  const unread = notifications.filter((notification) => !notification.read);
  const currentProject = pickPrimaryProject(projects);
  const name = currentUser?.full_name || currentUser?.name || currentUser?.email?.split("@")?.[0] || "Utilisateur";
  const progress = currentProject?.progress_percent ?? 0;
  const supportHint = uiCopy().supportHint;
  const roleStatus = formatRoleStatus(role);
  const activeConversation = conversations[0] || null;
  const topMatch = matches[0] || null;
  const roleStats = [
    { label: "Organisations", value: String(summary.organizations ?? 0), detail: "Organisation(s) connectée(s)" },
    { label: "Utilisateurs", value: String(summary.users ?? 0), detail: "Comptes disponibles" },
    { label: "Biens", value: String(summary.published_properties ?? 0), detail: "Biens publiés" },
    { label: "Conversations", value: String(summary.conversations ?? 0), detail: "Fils de discussion" },
    { label: "Messages", value: String(summary.messages ?? 0), detail: "Échanges actifs" },
    { label: "Notifications", value: String(summary.notifications ?? 0), detail: "Alertes à traiter" },
  ];

  refs.roleGreeting.textContent = `Bonjour, ${name}`;
  refs.roleSubtitle.textContent = `${config.subtitle} ${activeConversation ? `Conversation active: ${activeConversation.subject}` : ""}`.trim();
  refs.roleChip.textContent = roleStatus;
  refs.roleActivityChip.textContent = config.activity[0] || uiCopy().activity;
  if (refs.languageSelect) {
    refs.languageSelect.value = state.language;
  }
  if (refs.statsPeriodSelect) {
    refs.statsPeriodSelect.value = state.statsPeriod;
  }

  refs.progressCard.innerHTML = renderKeyValueRows(
    [
      { label: "Rôle", value: roleStatus, detail: "Profil actif" },
      {
        label: "Progression",
        value: `${progress}%`,
        detail: currentProject ? `${currentProject.title} · ${currentProject.project_type}` : "Aucun projet actif",
      },
      {
        label: "Prochaine étape",
        value: currentProject ? (currentProject.location?.city || currentProject.city || "Continuer") : "Définir un projet",
        detail: currentProject ? currentProject.objective || "Parcours en cours" : "Créez ou choisissez un projet",
      },
      {
        label: "Documents manquants",
        value: String(Math.max(0, unread.length)),
        detail: unread[0]?.title || "Aucune alerte critique",
      },
    ],
    "Aucun parcours actif.",
  );

  refs.activityCard.innerHTML = renderKeyValueRows(
    [
      { label: "Aujourd'hui", value: `${summary.events ?? 0} événements`, detail: "Journal d'activité" },
      { label: "Notifications", value: `${unread.length} non lues`, detail: unread[0]?.title || "Rien à relancer" },
      { label: "Conversations", value: `${conversations.length} ouvertes`, detail: activeConversation?.subject || "Aucun fil actif" },
      { label: "Biens", value: `${summary.published_properties ?? 0} publiés`, detail: topMatch?.property?.title || "Catalogue disponible" },
    ],
    "Aucune activité disponible.",
  );

  const priorityItems = [
    ...(unread.slice(0, 2).map((notification) => `${notification.title} · ${notification.kind}`) || []),
    ...(conversations.slice(0, 2).map((conversation) => `${conversation.subject} · ${conversation.status}`) || []),
    ...config.priorities,
  ].slice(0, 4);
  refs.prioritiesCard.innerHTML = renderPillList(priorityItems, "Aucune priorité détectée.");

  refs.quickActionsCard.innerHTML = renderActionLinks(config.quickActions);

  const statsPeriodLabel =
    refs.statsPeriodSelect?.selectedOptions?.[0]?.textContent || (state.statsPeriod === "7d" ? "7 jours" : state.statsPeriod === "30d" ? "30 jours" : state.statsPeriod === "year" ? "Année" : state.statsPeriod === "custom" ? "Période personnalisée" : "Aujourd'hui");
  refs.statsCard.innerHTML = `
    <div class="cockpit-stack">
      <p class="muted">Période active: ${escapeHtml(statsPeriodLabel)}</p>
      <div class="stats-mini-grid">
        ${roleStats
          .map(
            (stat) => `
              <article class="mini-stat">
                <span class="stat-label">${escapeHtml(stat.label)}</span>
                <strong>${escapeHtml(stat.value)}</strong>
                <span class="muted">${escapeHtml(stat.detail)}</span>
              </article>
            `,
          )
          .join("")}
      </div>
    </div>
  `;

  refs.recommendationsCard.innerHTML = renderPillList(
    (matches
      .slice(0, 4)
      .map((match) => `${match.property?.title || match.title || "Bien"} · score ${match.score ?? match.score_percent ?? "n/a"}`)
      .concat(config.recommendations)
      .slice(0, 4)) || [],
    "Aucune recommandation disponible.",
  );

  refs.nextActionsCard.innerHTML = renderPillList(
    config.nextActions.concat(currentProject ? [`Poursuivre ${currentProject.title}`] : []).slice(0, 4),
    "Aucune suggestion immédiate.",
  );

  refs.supportCard.innerHTML = `
    <div class="cockpit-stack">
      <p class="muted">${escapeHtml(supportHint)}</p>
      ${renderPillList(config.support, "Aucune catégorie")}
      <div class="action-link-grid">
        <a class="button primary action-link" href="#message-form">Ouvrir le module</a>
        <a class="button secondary action-link" href="#notification-filter-form">Voir les notifications</a>
      </div>
    </div>
  `;

  traceRuntime("DASHBOARD_RENDERED", {
    role,
    journey: role,
    progress,
    unread: unread.length,
    projects: projects.length,
  });
  traceRuntime("ROLE_DASHBOARD_RENDERED", {
    role,
    journey: role,
    visible: true,
  });
}

function renderOrganizations(items) {
  renderList(refs.organizationsList, items, (organization) => {
    const article = document.createElement("article");
    article.className = "mini-card";
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(organization.name)}</strong>
        <span class="chip subtle">${escapeHtml(organization.kind)}</span>
      </div>
      <p class="muted">${escapeHtml(organization.slug)}</p>
      <p>${escapeHtml(organization.city || "No city")} · ${organization.user_count ?? 0} users</p>
    `;
    return article;
  }, "No organizations available.");

  const options = ['<option value="">None</option>']
    .concat(items.map((organization) => `<option value="${organization.id}">${escapeHtml(organization.name)}</option>`))
    .join("");
  refs.ownerOrganizationSelect.innerHTML = options;
  if (refs.registerOrganizationSelect) {
    refs.registerOrganizationSelect.innerHTML = options;
  }
  if (refs.adminOrganizationSelect) {
    refs.adminOrganizationSelect.innerHTML = ['<option value="">Select organization</option>']
      .concat(items.map((organization) => `<option value="${organization.id}">${escapeHtml(organization.name)}</option>`))
      .join("");
  }
}

function renderProjects(items) {
  if (!refs.projectsList) {
    return;
  }
  renderList(refs.projectsList, items, (project) => {
    const article = document.createElement("article");
    article.className = "mini-card mini-card--project";
    const budget = project.budget || {};
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(project.title)}</strong>
        <span class="${statusChipClass(project.status)}">${escapeHtml(project.status)}</span>
      </div>
      <p class="muted">${escapeHtml(project.project_type)} · ${project.progress_percent ?? 0}% · ${escapeHtml(project.priority || "normal")}</p>
      <p>${escapeHtml(project.location?.city || "—")} · ${money(budget.min, budget.currency)} - ${money(budget.max, budget.currency)}</p>
      <p class="muted">${escapeHtml(project.objective || "")}</p>
    `;
    article.addEventListener("click", () => selectProject(project.id));
    return article;
  }, state.token ? "No projects yet — create one from the sidebar." : "Sign in to view projects.");
}

async function refreshEcosystemLists() {
  if (!state.token) {
    renderList(refs.partnersList, [], () => document.createElement("div"), "Sign in to load partners.");
    renderList(refs.servicesList, [], () => document.createElement("div"), "Sign in to load services.");
    return;
  }
  try {
    const [partnersPayload, servicesPayload] = await Promise.all([
      api("/api/v2/partners", { auth: true, query: { limit: 8 } }),
      api("/api/v2/services", { auth: true, query: { limit: 8 } }),
    ]);
    renderList(refs.partnersList, partnersPayload.partners || [], (partner) => {
      const article = document.createElement("article");
      article.className = "mini-card";
      article.innerHTML = `
        <strong>${escapeHtml(partner.display_name)}</strong>
        <p class="muted">${escapeHtml(partner.partner_type)} · Trust ${partner.trust_score ?? "n/a"}</p>
      `;
      return article;
    }, "No partners in directory.");
    renderList(refs.servicesList, servicesPayload.services || [], (service) => {
      const article = document.createElement("article");
      article.className = "mini-card";
      const pricing = service.pricing || {};
      article.innerHTML = `
        <strong>${escapeHtml(service.title)}</strong>
        <p class="muted">${escapeHtml(service.category)} · ${money(pricing.min, pricing.currency)} - ${money(pricing.max, pricing.currency)}</p>
      `;
      return article;
    }, "No services in catalog.");
  } catch (error) {
    renderList(refs.partnersList, [], () => document.createElement("div"), error.message);
  }
}

async function selectProject(projectId) {
  if (!state.token || !refs.projectDetail) {
    return;
  }
  state.selectedProjectId = projectId;
  try {
    const [payload, orchPayload, matchPayload, wfPayload, graphPayload, intelPayload, nbaPayload, risksPayload, oppPayload] = await Promise.all([
      api(`/api/v2/projects/${projectId}/workspace`, { auth: true }),
      api(`/api/v2/projects/${projectId}/orchestration`, { auth: true }),
      api(`/api/v2/matching?project_id=${projectId}`, { auth: true }),
      api(`/api/v2/projects/${projectId}/workflows`, { auth: true }),
      api("/api/v2/knowledge/graph", { auth: true, query: { project_id: projectId } }),
      api("/api/v2/intelligence", { auth: true, query: { project_id: projectId } }),
      api("/api/v2/next-actions", { auth: true, query: { project_id: projectId } }),
      api("/api/v2/risks", { auth: true, query: { project_id: projectId } }),
      api("/api/v2/opportunities", { auth: true, query: { project_id: projectId } }),
    ]);
    const workspace = payload.workspace || payload;
    const orchestration = orchPayload.orchestration || {};
    const matches = matchPayload.matches || [];
    const workflow = wfPayload.workflow_instance || {};
    const graph = graphPayload.graph || {};
    const cognitionIntel = intelPayload.intelligence || {};
    const nextAction = nbaPayload.next_action || {};
    const cognitionRisks = risksPayload.risks || [];
    const cognitionOpportunities = oppPayload.opportunities || [];
    const project = workspace.project;
    const progress = workspace.progress || {};
    const stepsHtml = (workspace.steps || [])
      .map(
        (step) => `
          <article class="message">
            <div class="message__meta">
              <strong>${escapeHtml(step.title)}</strong>
              <span class="chip subtle">${escapeHtml(step.status)}</span>
            </div>
            <p class="muted">${escapeHtml(step.milestone || "")} · ${escapeHtml(step.next_action || "")}</p>
          </article>
        `,
      )
      .join("");
    const goalsHtml = (workspace.goals || [])
      .slice(0, 5)
      .map((goal) => `<li>${escapeHtml(goal.title || goal.goal_key)} · ${escapeHtml(goal.status || "active")}</li>`)
      .join("");
    const timeline = workspace.timeline || {};
    const timelineHtml = (timeline.past_events || timeline.history || [])
      .slice(0, 4)
      .map((entry) => `<li>${escapeHtml(entry.title || entry.to_status || entry.kind || "Event")}</li>`)
      .join("");
    const tasksHtml = (workspace.tasks || [])
      .slice(0, 5)
      .map((task) => `<li>${escapeHtml(task.title)} · ${escapeHtml(task.status || "pending")}</li>`)
      .join("");
    const lifeEventsHtml = (workspace.life_events || [])
      .slice(0, 4)
      .map((event) => `<li>${escapeHtml(event.title || event.event_type)}</li>`)
      .join("");
    const graphNodesHtml = (graph.nodes || [])
      .slice(0, 6)
      .map((node) => `<li>${escapeHtml(node.title || node.node_key)} · ${escapeHtml(node.node_type || "")}</li>`)
      .join("");
    const cognitionRisksHtml = cognitionRisks
      .slice(0, 4)
      .map((risk) => `<li>${escapeHtml(risk.risk_key || "risk")} · score ${risk.score ?? "n/a"}</li>`)
      .join("");
    const cognitionOpportunitiesHtml = cognitionOpportunities
      .slice(0, 4)
      .map((item) => `<li>${escapeHtml(item.opportunity_key || "opportunity")} · ${item.opportunity_score ?? "n/a"}</li>`)
      .join("");
    const knowledgeHtml = (workspace.knowledge || [])
      .slice(0, 4)
      .map((fact) => `<li>${escapeHtml(fact.title)} · ${escapeHtml(fact.category || "")}</li>`)
      .join("");
    const actionsListHtml = (workspace.actions || [])
      .slice(0, 4)
      .map((action) => `<li>${escapeHtml(action.title)} · ${escapeHtml(action.status || "pending")}</li>`)
      .join("");
    const recommendationsHtml = (workspace.recommendations || workspace.next_actions || [])
      .slice(0, 3)
      .map((action) => `<li>${escapeHtml(action.title || action.next_action || "Action")}</li>`)
      .join("");
    const partnerMatchesHtml = matches
      .filter((m) => m.match_type === "partner" || m.partner)
      .slice(0, 4)
      .map((m) => {
        const label = m.partner?.display_name || m.partner_type || "Partner";
        return `<li>${escapeHtml(label)} · score ${m.score} · ${escapeHtml((m.rationale?.[0]?.label) || "")}</li>`;
      })
      .join("");
    const serviceMatchesHtml = matches
      .filter((m) => m.match_type === "service" || m.service)
      .slice(0, 4)
      .map((m) => {
        const label = m.service?.title || m.service_key || "Service";
        return `<li>${escapeHtml(label)} · score ${m.score}</li>`;
      })
      .join("");
    const interventionsHtml = (orchestration.planning || [])
      .slice(0, 4)
      .map((item) => `<li>${escapeHtml(item.title || item.type)} · ${escapeHtml(item.status || "")}</li>`)
      .join("");
    refs.projectDetail.innerHTML = `
      <div class="detail-summary">
        <div>
          <p class="eyebrow">${escapeHtml(project.project_type)} project</p>
          <h3>${escapeHtml(project.title)}</h3>
          <p>${escapeHtml(project.objective)}</p>
          <p class="muted">Progress ${progress.progress_percent ?? 0}% · ${progress.steps_completed ?? 0}/${progress.steps_total ?? 0} steps · Journey ${escapeHtml(workspace.journey?.status || workspace.journey_state?.status || "active")}</p>
        </div>
      </div>
      <div class="detail-grid">
        <section>
          <h4>Ecosystem — partner matches</h4>
          <ul>${partnerMatchesHtml || "<li class='muted'>No partner matches</li>"}</ul>
        </section>
        <section>
          <h4>Ecosystem — service matches</h4>
          <ul>${serviceMatchesHtml || "<li class='muted'>No service matches</li>"}</ul>
        </section>
        <section>
          <h4>Workflow</h4>
          <p class="muted">${escapeHtml(workflow.status || "—")} · ${workflow.progress_percent ?? 0}% · step ${escapeHtml(workflow.current_step_key || "—")}</p>
        </section>
        <section>
          <h4>Interventions</h4>
          <ul>${interventionsHtml || "<li class='muted'>No interventions planned</li>"}</ul>
        </section>
        <section>
          <h4>Orchestration</h4>
          <p class="muted">${orchestration.partners_engaged ?? 0} partners · ${orchestration.services_recommended ?? 0} services · ${money(orchestration.cost_summary?.estimated, orchestration.cost_summary?.currency)} estimated</p>
        </section>
        <section>
          <h4>Goals</h4>
          <ul>${goalsHtml || "<li class='muted'>No goals</li>"}</ul>
        </section>
        <section>
          <h4>Recommendations</h4>
          <ul>${recommendationsHtml || "<li class='muted'>No recommendations</li>"}</ul>
        </section>
        <section>
          <h4>Intelligence</h4>
          <p class="muted">Blockers: ${workspace.intelligence?.blockers?.open_high_risks ?? 0} high risks · Trust ${workspace.trust_score?.score ?? "n/a"}</p>
          <p class="muted">Priorities: ${escapeHtml((workspace.intelligence?.priorities || []).slice(0, 2).join(" · ") || "—")}</p>
        </section>
        <section>
          <h4>Timeline</h4>
          <ul>${timelineHtml || "<li class='muted'>No timeline entries</li>"}</ul>
        </section>
        <section>
          <h4>Actions</h4>
          <ul>${actionsListHtml || "<li class='muted'>No actions</li>"}</ul>
        </section>
        <section>
          <h4>Tasks</h4>
          <ul>${tasksHtml || "<li class='muted'>No tasks</li>"}</ul>
        </section>
        <section>
          <h4>Life events</h4>
          <ul>${lifeEventsHtml || "<li class='muted'>No life events</li>"}</ul>
        </section>
        <section>
          <h4>Knowledge graph</h4>
          <p class="muted">${(graph.nodes || []).length} nodes · ${(graph.edges || []).length} edges</p>
          <ul>${graphNodesHtml || "<li class='muted'>No graph nodes</li>"}</ul>
        </section>
        <section>
          <h4>Decision platform</h4>
          <p class="muted">${escapeHtml(nextAction.title || "—")} · confidence ${nextAction.confidence ?? "n/a"}</p>
          <p class="muted">${escapeHtml(nextAction.justification || cognitionIntel.snapshot?.decision?.reason || "—")}</p>
        </section>
        <section>
          <h4>Next best action</h4>
          <p class="muted">${escapeHtml(nextAction.title || "—")} · score ${nextAction.score ?? "n/a"}</p>
        </section>
        <section>
          <h4>Risk intelligence</h4>
          <ul>${cognitionRisksHtml || "<li class='muted'>No risk scores</li>"}</ul>
        </section>
        <section>
          <h4>Opportunity intelligence</h4>
          <ul>${cognitionOpportunitiesHtml || "<li class='muted'>No opportunities scored</li>"}</ul>
        </section>
        <section>
          <h4>Knowledge</h4>
          <ul>${knowledgeHtml || "<li class='muted'>No knowledge facts</li>"}</ul>
        </section>
      </div>
      <h4>Journey steps</h4>
      <div class="message-stream">${stepsHtml}</div>
    `;
  } catch (error) {
    refs.projectDetail.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
  await refreshAssistant(state.selectedProjectId);
}

async function refreshAssistant(projectId) {
  if (!state.token || !projectId || !refs.assistantSummary) {
    if (refs.assistantForm) {
      refs.assistantForm.classList.add("hidden");
    }
    return;
  }
  try {
    const [agentsPayload, messagesPayload] = await Promise.all([
      api("/api/v2/assistant/agents", { auth: true }),
      api(`/api/v2/assistant/sessions?project_id=${projectId}`, { auth: true }),
    ]);
    const sessions = messagesPayload.sessions || [];
    const session = sessions[0];
    state.assistantSessionId = session?.id || null;
    refs.assistantSummary.innerHTML = `
      <p class="muted">${(agentsPayload.agents || []).length} agents · session ${session?.session_key || "new"}</p>
    `;
    refs.assistantForm?.classList.remove("hidden");
    if (session?.id) {
      const msgPayload = await api(
        `/api/v2/assistant/messages?project_id=${projectId}&session_id=${session.id}`,
        { auth: true },
      );
      const messages = msgPayload.messages || [];
      if (refs.assistantChat) {
        refs.assistantChat.innerHTML = messages
          .map(
            (msg) => `
              <article class="message">
                <div class="message__meta"><strong>${escapeHtml(msg.role)}</strong></div>
                <p>${escapeHtml(msg.content)}</p>
              </article>
            `,
          )
          .join("") || "<p class='muted'>No assistant messages yet.</p>";
      }
    } else if (refs.assistantChat) {
      refs.assistantChat.innerHTML = "<p class='muted'>No assistant messages yet.</p>";
    }
  } catch (error) {
    refs.assistantSummary.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleAssistantChat(event) {
  event.preventDefault();
  if (!state.token || !state.selectedProjectId || !refs.assistantForm) {
    return;
  }
  const form = new FormData(refs.assistantForm);
  const message = String(form.get("message") || "").trim();
  if (!message) {
    return;
  }
  try {
    const body = { project_id: state.selectedProjectId, message };
    if (state.assistantSessionId) {
      body.session_id = state.assistantSessionId;
    }
    await api("/api/v2/assistant/chat", { auth: true, method: "POST", body });
    refs.assistantForm.reset();
    await refreshAssistant(state.selectedProjectId);
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function refreshProjects() {
  if (!state.token || !refs.projectsList) {
    renderProjects([]);
    return;
  }
  try {
    const payload = await api("/api/v2/projects", { auth: true, query: { limit: 20 } });
    renderProjects(payload.projects || []);
    if (state.selectedProjectId) {
      await selectProject(state.selectedProjectId);
    }
  } catch (error) {
    renderProjects([]);
  }
}

function renderProperties(items) {
  const mediaOptions = ['<option value="">Select property</option>']
    .concat(
      (items || []).map((property) => {
        const label = property.listing_code || property.title;
        return `<option value="${property.id}">${escapeHtml(label)}</option>`;
      }),
    )
    .join("");
  refs.mediaPropertySelect.innerHTML = mediaOptions;

  renderList(refs.propertiesList, items, (property) => {
    const price = propertyPrice(property);
    const geo = propertyGeo(property);
    const coords = geo.coordinates || {};
    const article = document.createElement("article");
    article.className = "mini-card mini-card--property";
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(property.title)}</strong>
        <span class="${statusChipClass(property.status)}" data-status="${escapeHtml(property.status || "draft")}">${escapeHtml(property.status || "draft")}</span>
      </div>
      <p class="muted">${escapeHtml(property.listing_code || "no-code")} · ${escapeHtml(property.property_type || "n/a")} · ${escapeHtml(property.availability || "available")}</p>
      <p>${escapeHtml(geo.city || "n/a")}, ${escapeHtml(geo.region || "—")}, ${escapeHtml(geo.country || "n/a")}</p>
      <p>${money(price.min, price.currency)} - ${money(price.max, price.currency)}</p>
      <p class="muted">Coords: ${coords.latitude ?? "—"}, ${coords.longitude ?? "—"}</p>
      <p class="muted">Owner: ${escapeHtml(property.ownership?.organization_name || property.owner_organization_name || "n/a")} · Media: ${property.media_count ?? 0}</p>
      <p>${escapeHtml(property.summary || "")}</p>
    `;
    article.addEventListener("click", () => {
      state.selectedPropertyId = property.id;
      state.selectedPropertyVersion = property.version;
      state.selectedPropertyTitle = property.title;
      updateSelectedPropertyLabel();
      setNotice(`Selected property #${property.id} (${property.title})`, "neutral");
    });
    return article;
  }, "No properties available.");
}

function renderMedia(items) {
  renderList(refs.mediaList, items, (media) => {
    const article = document.createElement("article");
    article.className = "mini-card mini-card--media";
    const preview =
      media.mime_type?.startsWith("image/") && media.url
        ? `<img class="media-preview" src="${escapeHtml(media.url)}" alt="${escapeHtml(media.caption || media.kind)}" loading="lazy">`
        : "";
    article.innerHTML = `
      ${preview}
      <div class="mini-card__header">
        <strong>${escapeHtml(media.caption || media.kind)}</strong>
        <span class="chip subtle">${escapeHtml(media.kind)}</span>
      </div>
      <p class="muted">${escapeHtml(media.property_title || `Property #${media.property_id}`)}</p>
      <p>${escapeHtml(media.mime_type || "unknown")} · ${media.size_bytes ?? 0} bytes</p>
      <p class="muted">${escapeHtml(media.url)}</p>
    `;
    return article;
  }, "No media available.");
}

function renderMatches(items) {
  renderList(refs.matchesList, items, (match) => {
    const property = match.property;
    const price = propertyPrice(property);
    const geo = propertyGeo(property);
    const breakdown = match.breakdown || {};
    const breakdownText = Object.entries(breakdown)
      .map(([key, value]) => `${key}:${value}`)
      .join(" · ");
    const article = document.createElement("article");
    article.className = "mini-card mini-card--match";
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(property.title)}</strong>
        <span class="chip accent">${match.score} · ${escapeHtml(match.grade || "n/a")}</span>
      </div>
      <p class="muted">${escapeHtml(geo.city || property.city)}, ${escapeHtml(geo.country || property.country)}</p>
      <p>${money(price.min, price.currency)} - ${money(price.max, price.currency)}</p>
      <p class="muted">${escapeHtml(match.summary || (match.reasons || []).join(" · ") || "No summary.")}</p>
      <p class="muted breakdown">${escapeHtml(breakdownText || "No score breakdown.")}</p>
    `;
    return article;
  }, "No match results yet.");
}

function conversationRequester(conversation) {
  return conversation.requester?.full_name || conversation.requester_name || "n/a";
}

function conversationPropertyTitle(conversation) {
  return conversation.property?.title || conversation.property_title || "n/a";
}

function messageSenderName(message) {
  return message.sender?.full_name || message.sender_name || "n/a";
}

function renderConversationDetail(conversation) {
  const messages = conversation.messages || [];
  const negotiation = conversation.negotiation || {};
  const allowedStages = negotiation.allowed_stages || [];
  refs.conversationDetail.innerHTML = `
    <div class="detail-summary">
      <div>
        <p class="eyebrow">
          <span class="chip subtle" data-status="${escapeHtml(conversation.status)}">${escapeHtml(conversation.status)}</span>
          <span class="chip accent">${escapeHtml(conversation.negotiation_stage || negotiation.stage || "inquiry")}</span>
        </p>
        <h3>${escapeHtml(conversation.subject)}</h3>
        <p class="muted">
          Requester: ${escapeHtml(conversationRequester(conversation))} · Property: ${escapeHtml(conversationPropertyTitle(conversation))}
        </p>
      </div>
      <div class="detail-badge">
        <span>Messages</span>
        <strong>${conversation.message_count ?? messages.length}</strong>
      </div>
    </div>
    <div class="message-stream">
      ${messages
        .map(
          (message) => `
            <article class="message">
              <div class="message__meta">
                <strong>${escapeHtml(messageSenderName(message))}</strong>
                <span class="muted">${escapeHtml(message.created_at)}</span>
              </div>
              <p>${escapeHtml(message.body)}</p>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
  refs.messageForm.classList.toggle("hidden", !state.token);
  if (refs.negotiationForm) {
    const stageSelect = refs.negotiationForm.querySelector('[name="negotiation_stage"]');
    if (stageSelect) {
      stageSelect.innerHTML = allowedStages
        .map((stage) => `<option value="${stage}" ${stage === (conversation.negotiation_stage || "inquiry") ? "selected" : ""}>${stage}</option>`)
        .join("");
    }
    refs.negotiationForm.classList.toggle("hidden", !state.token || !allowedStages.length);
  }
}

function renderNotifications(items) {
  const unread = (items || []).filter((notification) => !notification.read).length;
  if (refs.notificationUnreadCount) {
    refs.notificationUnreadCount.textContent = `${unread} non lues`;
    refs.notificationUnreadCount.dataset.tone = unread ? "warn" : "ok";
  }
  renderList(refs.notificationsList, items, (notification) => {
    const article = document.createElement("article");
    article.className = "mini-card mini-card--notification";
    if (!notification.read) {
      article.dataset.unread = "true";
    }
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(notification.title)}</strong>
        <span class="chip subtle">${escapeHtml(notification.kind)}</span>
      </div>
      <p>${escapeHtml(notification.body)}</p>
      <p class="muted">${notification.read ? "read" : "unread"} · ${escapeHtml(notification.created_at || "")}</p>
    `;
    article.addEventListener("click", () => markNotificationRead(notification.id));
    return article;
  }, "No notifications yet.");
}

async function refreshNotifications() {
  if (!state.token) {
    renderNotifications([]);
    return;
  }
  const form = refs.notificationFilterForm ? new FormData(refs.notificationFilterForm) : null;
  const payload = await api("/api/notifications", {
    auth: true,
    query: {
      limit: 20,
      kind: form?.get("kind") || undefined,
      unread_only: form?.get("unread_only") ? "true" : undefined,
    },
  });
  renderNotifications(payload.notifications || []);
}

async function markNotificationRead(notificationId) {
  if (!state.token) {
    return;
  }
  try {
    await api(`/api/notifications/${notificationId}/read`, { method: "PATCH", auth: true, body: {} });
    await refreshNotifications();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function markAllNotificationsRead() {
  if (!state.token) {
    return;
  }
  try {
    await api("/api/notifications/read-all", { method: "POST", auth: true, body: {} });
    await refreshNotifications();
    setNotice("All notifications marked as read.", "ok");
  } catch (error) {
    setNotice(error.message, "error");
  }
}

function renderConversations(items) {
  renderList(refs.conversationsList, items, (conversation) => {
    const article = document.createElement("article");
    article.className = "mini-card mini-card--conversation";
    if (conversation.id === state.selectedConversationId) {
      article.dataset.active = "true";
    }
    article.innerHTML = `
      <div class="mini-card__header">
        <strong>${escapeHtml(conversation.subject)}</strong>
        <span class="chip subtle">${escapeHtml(conversation.status)} · ${escapeHtml(conversation.negotiation_stage || "inquiry")}</span>
      </div>
      <p class="muted">${escapeHtml(conversationRequester(conversation))} · ${escapeHtml(conversationPropertyTitle(conversation))}</p>
      <p>${escapeHtml(conversation.last_message || "No messages yet.")}</p>
    `;
    article.addEventListener("click", () => selectConversation(conversation.id));
    return article;
  }, "No conversations available.");
}

function updateSelectedPropertyLabel() {
  if (!refs.selectedPropertyLabel) {
    return;
  }
  if (!state.selectedPropertyId) {
    refs.selectedPropertyLabel.textContent = "No property selected.";
    return;
  }
  refs.selectedPropertyLabel.textContent = `#${state.selectedPropertyId} · ${state.selectedPropertyTitle || "Property"} · v${state.selectedPropertyVersion ?? "?"}`;
}

function applyJourney(journey) {
  traceRuntime("APPLY_JOURNEY", { journey });
  state.activeJourney = journey;
  localStorage.setItem("lawim.journey", journey);
  updateAuthShell(Boolean(state.token));
  const visibleKeys = state.token ? (ROLE_JOURNEY_KEYS[journey] || ROLE_JOURNEY_KEYS.user) : [];
  document.querySelectorAll("[data-journey-panel]").forEach((panel) => {
    if (!state.token) {
      panel.hidden = true;
      return;
    }
    const allowed = (panel.getAttribute("data-journey-panel") || "").split(/\s+/);
    panel.hidden = !allowed.some((key) => visibleKeys.includes(key));
  });
  document.querySelectorAll("#journey-nav [data-journey]").forEach((button) => {
    button.dataset.active = button.getAttribute("data-journey") === journey ? "true" : "false";
  });
  if (journey === "admin" && state.token) {
    loadAdminDashboard();
  }
  traceRuntime("RENDER_DONE", {
    journey,
    adminDashboardVisible: Boolean(refs.adminDashboard && !refs.adminDashboard.hidden),
  });
}

function journeyForRole(role) {
  const normalizedRole = normalizeAccessRole(role);
  return normalizedRole || "user";
}

async function loadAdminDashboard() {
  if (!refs.adminDashboard || !state.token) {
    return;
  }
  try {
    const [metrics, events] = await Promise.all([
      api("/api/metrics", { auth: true }),
      api("/api/events?limit=10", { auth: true }),
    ]);
    const counters = metrics.metrics || {};
    refs.adminDashboard.innerHTML = `
      <div class="detail-summary">
        <div>
          <p class="eyebrow">Runtime metrics</p>
          <p>Requests ${counters.requests_total ?? 0} · Matches ${counters.matches_total ?? 0} · Conversations ${counters.conversations_total ?? 0}</p>
        </div>
      </div>
      <div class="message-stream">
        ${(events.events || [])
          .map(
            (event) => `
              <article class="message">
                <div class="message__meta">
                  <strong>${escapeHtml(event.kind)}</strong>
                  <span class="muted">${escapeHtml(event.created_at)}</span>
                </div>
              </article>
            `,
          )
          .join("")}
      </div>
    `;
    traceRuntime("DASHBOARD_RENDERED", {
      journey: state.activeJourney,
      adminDashboardVisible: Boolean(refs.adminDashboard && !refs.adminDashboard.hidden),
    });
  } catch (error) {
    refs.adminDashboard.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

function renderHealth(health) {
  const environment = health.environment || {};
  const database = health.database || {};
  setRuntimeChip(`${health.status.toUpperCase()} · ${environment.app_env || "unknown"}`, health.status === "ok" ? "ok" : "warn");
  const metricsNote = health.metrics ? `${health.metrics.requests_total ?? 0} requêtes` : "métriques réservées aux administrateurs";
  refs.bootstrapSummary.textContent = `Pilote ${environment.db_driver || database.driver || "sqlite"} · schéma v${database.schema_version ?? "?"} · ${health.summary?.events ?? 0} événements · ${metricsNote}.`;
}

function renderBootstrap(payload) {
  state.bootstrap = payload;
  const currentUser = payload.current_user;

  if (currentUser) {
    const resolvedRole = resolveAccessRole(currentUser.role, currentUser.roles || payload.roles || []);
    state.activeJourney = journeyForRole(resolvedRole);
    refs.currentUser.textContent = `${currentUser.full_name || currentUser.name || "Utilisateur"} · ${currentUser.email || "n/a"} · ${roleLabel(resolvedRole)}`;
    refs.logoutButton.disabled = false;
    if (refs.roleCockpit) {
      refs.roleCockpit.hidden = false;
    }
    renderRoleCockpit(currentUser, payload);
  } else {
    refs.currentUser.textContent = uiCopy().session;
    refs.logoutButton.disabled = !state.token;
    if (refs.roleCockpit) {
      refs.roleCockpit.hidden = true;
    }
  }

  updateAuthShell(Boolean(state.token && currentUser));

  renderSummary(payload.summary || {});
  renderOrganizations(payload.organizations || []);
  renderProperties(payload.properties || []);
  renderMedia(payload.media || []);
  renderMatches(payload.matches || []);
  renderConversations(payload.conversations || []);
  renderNotifications(payload.notifications || []);

  if (state.token && !currentUser) {
    clearSession();
  }

  if (!state.selectedConversationId && (payload.conversations || []).length) {
    selectConversation(payload.conversations[0].id);
  } else if (state.selectedConversationId) {
    const current = (payload.conversations || []).find((conversation) => conversation.id === state.selectedConversationId);
    if (current) {
      selectConversation(current.id);
    } else {
      state.selectedConversationId = null;
      refs.conversationDetail.innerHTML = '<p class="muted">No conversation selected.</p>';
    }
  }
}

async function selectConversation(conversationId) {
  state.selectedConversationId = conversationId;
  try {
    const payload = await api(`/api/conversations/${conversationId}`, { auth: true });
    renderConversationDetail(payload.conversation);
    renderConversations(state.bootstrap?.conversations || []);
  } catch (error) {
    state.selectedConversationId = null;
    refs.conversationDetail.innerHTML = `<p class="muted">${error.message}</p>`;
    setNotice(error.message, "error", error.code || "");
  }
}

function parseNumber(value) {
  if (value === "" || value === null || value === undefined) {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

async function refresh({ renderJourney = true } = {}) {
  if (state.refreshInFlight) {
    return;
  }
  state.refreshInFlight = true;
  traceRuntime("REFRESH_START", {
    token: Boolean(state.token),
    journey: state.activeJourney,
    renderJourney,
  });
  setLoading(true, "Actualisation de l'environnement...");
  let refreshError = null;
  try {
    const healthPromise = api("/api/health", { auth: Boolean(state.token) });
    const bootstrapPromise = api("/api/bootstrap", { auth: Boolean(state.token) });
    const [health, bootstrap] = await Promise.all([healthPromise, bootstrapPromise]);
    state.health = health;
    try {
      renderHealth(health);
    } catch (error) {
      refreshError = error;
      setRuntimeChip("DEGRADED", "warn");
    }
    renderBootstrap(bootstrap);
    await refreshProjects();
    await refreshEcosystemLists();
    await refreshKnowledgeAdmin();
    await refreshReiAdmin();
    await refreshCrmAdmin();
    await refreshCommunicationAdmin();
    await refreshAnalyticsAdmin();
    await refreshSourceIntelligenceAdmin();
    await refreshSecurityAdmin();
    await refreshMarketplaceAdmin();
    await refreshWorkflowAdmin();
    if (renderJourney) {
      applyJourney(state.activeJourney);
    }
    setNotice("Environnement prêt.", "success");
  } catch (error) {
    refreshError = error;
    const sessionError = formatSessionError(error);
    if (sessionError.clearToken) {
      clearSession();
    }
    setNotice(sessionError.message, sessionError.tone, error.code || "");
    setRuntimeChip("DEGRADED", "warn");
  } finally {
    traceRuntime("REFRESH_DONE", {
      token: Boolean(state.token),
      journey: state.activeJourney,
      renderJourney,
      error: refreshError ? refreshError.message : null,
    });
    state.refreshInFlight = false;
    setLoading(false);
  }
}

async function refreshKnowledgeAdmin() {
  if (!state.token || !refs.knowledgeAdminStats) {
    return;
  }
  try {
    const [statsPayload, docsPayload, catsPayload] = await Promise.all([
      api("/api/v2/knowledge/stats", { auth: true }),
      api("/api/v2/knowledge/documents", { auth: true }),
      api("/api/v2/knowledge/categories", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    refs.knowledgeAdminStats.innerHTML = `
      <p class="muted">${stats.documents ?? 0} documents · ${stats.chunks ?? 0} chunks · ${stats.categories ?? 0} categories</p>
    `;
    refs.knowledgeSearchForm?.classList.remove("hidden");
    const docs = docsPayload.documents || [];
    refs.knowledgeAdminList.innerHTML = docs
      .slice(0, 8)
      .map(
        (doc) => `
          <article class="mini-card">
            <strong>${escapeHtml(doc.title)}</strong>
            <p class="muted">${escapeHtml(doc.status || "draft")} · ${escapeHtml(doc.format || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No expert documents.</p>";
  } catch (error) {
    refs.knowledgeAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleKnowledgeSearch(event) {
  event.preventDefault();
  if (!state.token || !refs.knowledgeSearchForm) {
    return;
  }
  const query = String(new FormData(refs.knowledgeSearchForm).get("query") || "").trim();
  if (!query) {
    return;
  }
  try {
    const payload = await api(`/api/v2/knowledge/search?q=${encodeURIComponent(query)}`, { auth: true });
    const results = payload.results || [];
    refs.knowledgeSearchResults.innerHTML = results
      .map(
        (row) => `
          <article class="message">
            <div class="message__meta"><strong>${escapeHtml(row.title || "Result")}</strong> · score ${row.score ?? 0}</div>
            <p class="muted">${escapeHtml(row.snippet || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No results.</p>";
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function refreshCommunicationAdmin() {
  if (!state.token || !refs.communicationAdminStats) {
    return;
  }
  try {
    const [statsPayload, messagesPayload, channelsPayload] = await Promise.all([
      api("/api/v2/communication/statistics", { auth: true }),
      api("/api/v2/communication/messages", { auth: true }),
      api("/api/v2/communication/channels", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    refs.communicationAdminStats.innerHTML = `
      <p class="muted">${stats.messages ?? 0} messages · ${stats.notifications ?? 0} notifications · ${stats.queue_pending ?? 0} queue pending · ${stats.campaigns ?? 0} campaigns</p>
    `;
    const messages = messagesPayload.messages || [];
    refs.communicationAdminList.innerHTML = messages
      .slice(0, 6)
      .map(
        (message) => `
          <article class="mini-card">
            <strong>${escapeHtml(message.subject || message.channel_type || "Message")}</strong>
            <p class="muted">${escapeHtml(message.status || "")} · ${escapeHtml(message.channel_type || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No communication messages loaded.</p>";
    const channels = channelsPayload.channels || [];
    if (channels.length && refs.communicationAdminList) {
      const channelSummary = channels
        .slice(0, 3)
        .map((channel) => escapeHtml(channel.name || channel.channel_type || ""))
        .join(" · ");
      if (channelSummary) {
        refs.communicationAdminStats.innerHTML += `<p class="muted">Channels: ${channelSummary}</p>`;
      }
    }
  } catch (error) {
    refs.communicationAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function refreshAnalyticsAdmin() {
  if (!state.token || !refs.analyticsAdminStats) {
    return;
  }
  try {
    const [statsPayload, executivePayload, integrationsPayload] = await Promise.all([
      api("/api/v2/analytics/statistics", { auth: true }),
      api("/api/v2/analytics/executive", { auth: true }),
      api("/api/v2/analytics/integrations", { auth: true }),
    ]);
    const stats = statsPayload.statistics || {};
    refs.analyticsAdminStats.innerHTML = `
      <p class="muted">${stats.total_kpis ?? 0} KPI · ${stats.dashboards_active ?? 0} dashboards · ${stats.reports_generated ?? 0} reports · ${stats.exports_completed ?? 0} exports · ${stats.ai_insights ?? 0} AI insights · health ${stats.platform_health_score ?? 0}</p>
    `;
    const executive = executivePayload.executive || {};
    const kpis = executive.kpis || [];
    refs.analyticsAdminList.innerHTML = kpis
      .slice(0, 6)
      .map(
        (kpi) => `
          <article class="mini-card">
            <strong>${escapeHtml(kpi.name || kpi.kpi_key || "KPI")}</strong>
            <p class="muted">${escapeHtml(String(kpi.value ?? 0))}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No executive KPIs loaded.</p>";
    const programs = integrationsPayload.programs || {};
    const integrated = Object.values(programs).filter(Boolean).length;
    refs.analyticsAdminStats.innerHTML += `<p class="muted">Sources integrated: ${integrated} programs</p>`;
  } catch (error) {
    refs.analyticsAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

function fillSourceIntelligenceForm(source) {
  if (!refs.sieSourceForm || !source) {
    return;
  }
  const elements = refs.sieSourceForm.elements;
  const setValue = (name, value) => {
    if (elements[name]) {
      elements[name].value = value ?? "";
    }
  };
  setValue("source_id", source.id ?? "");
  setValue("network", source.network || source.channel || "");
  setValue("publication_url", source.publication_url || "");
  setValue("publication_title", source.publication_title || source.name || "");
  setValue("publication_text", source.publication_text || "");
  setValue("publication_author", source.publication_author || "");
  setValue("campaign", source.campaign || "");
  setValue("city", source.city || "");
  setValue("district", source.district || "");
  setValue("property_type", source.property_type || "");
  setValue("target_audience", source.target_audience || "");
  setValue("format", source.format || "");
  setValue("language", source.language || "");
  setValue("tags", Array.isArray(source.tags) ? source.tags.join(", ") : "");
  setValue("ai_classification", source.ai_classification || "");
  setValue("ai_confidence", source.ai_confidence ?? "");
  setValue("notes", source.notes || "");
}

function selectSourceIntelligence(source) {
  if (!source) {
    return;
  }
  state.selectedSourceIntelligenceId = source.id || null;
  fillSourceIntelligenceForm(source);
  if (refs.sieReferenceResult && source.reference_code) {
    refs.sieReferenceResult.innerHTML = `
      <article class="message">
        <div class="message__meta"><strong>${escapeHtml(source.name || source.source_key || "Source")}</strong> · ${escapeHtml(source.reference_code || "")}</div>
      </article>
    `;
  } else if (refs.sieReferenceResult) {
    refs.sieReferenceResult.innerHTML = "";
  }
  if (refs.sieLinkResult && source.whatsapp_link) {
    refs.sieLinkResult.innerHTML = `
      <article class="message">
        <div class="message__meta"><strong>WhatsApp</strong> · ${escapeHtml(source.whatsapp_link || "")}</div>
      </article>
    `;
  } else if (refs.sieLinkResult) {
    refs.sieLinkResult.innerHTML = "";
  }
}

async function refreshSourceIntelligenceAdmin() {
  if (!state.token || !refs.sieAdminStats || !refs.sieAdminList) {
    return;
  }
  try {
    const payload = await api("/api/v2/source-intelligence/dashboard", { auth: true, query: { limit: 8 } });
    const dashboard = payload.dashboard || {};
    const stats = dashboard.stats || {};
    state.sourceIntelligenceDashboard = dashboard;
    refs.sieAdminStats.innerHTML = `
      <p class="muted">${stats.total ?? 0} sources · ${stats.active ?? stats.active_sources ?? 0} active · ${stats.with_context ?? stats.sources_with_context ?? 0} with context · ${stats.imports_total ?? 0} imports · confidence ${(Number(stats.average_ai_confidence) || 0).toFixed(2)}</p>
    `;
    refs.sieImportForm?.classList.remove("hidden");
    refs.sieSourceForm?.classList.remove("hidden");
    refs.sieReferenceForm?.classList.remove("hidden");
    const sources = dashboard.top_sources || dashboard.sources || [];
    if (sources.length) {
      const selected =
        sources.find((source) => Number(source.id) === Number(state.selectedSourceIntelligenceId)) || sources[0];
      if (selected) {
        selectSourceIntelligence(selected);
      }
    }
    refs.sieAdminList.innerHTML = sources
      .slice(0, 8)
      .map(
        (source) => `
          <article class="mini-card" data-sie-source-id="${escapeHtml(String(source.id || ""))}">
            <strong>${escapeHtml(source.name || source.source_key || "Source")}</strong>
            <p class="muted">${escapeHtml(source.reference_code || "")} · ${escapeHtml(source.channel || source.network || "")} · ${escapeHtml(source.status || "")}</p>
            <p class="muted">${escapeHtml(source.city || "")} · leads ${source.lead_count ?? 0} · customers ${source.customer_count ?? 0} · imports ${source.import_count ?? 0}</p>
            <div class="actions single">
              <button type="button" class="button ghost" data-sie-select-source="${escapeHtml(String(source.id || ""))}">Select</button>
            </div>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No source intelligence records.</p>";
    refs.sieAdminList.querySelectorAll("[data-sie-select-source]").forEach((button) => {
      button.addEventListener("click", () => {
        const sourceId = Number(button.getAttribute("data-sie-select-source") || 0);
        const source = sources.find((item) => Number(item.id) === sourceId);
        if (source) {
          selectSourceIntelligence(source);
          setNotice(`Selected ${source.name || source.source_key || "source"}.`, "success");
        }
      });
    });
  } catch (error) {
    refs.sieAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleSourceIntelligenceImport(event) {
  event.preventDefault();
  if (!state.token || !refs.sieImportForm) {
    return;
  }
  try {
    const form = new FormData(refs.sieImportForm);
    const payload = await api("/api/v2/source-intelligence/imports", {
      method: "POST",
      auth: true,
      body: {
        url: form.get("url"),
        name: form.get("name"),
        channel: form.get("channel"),
        notes: form.get("notes"),
      },
    });
    const source = { ...(payload.source || {}), whatsapp_link: payload.whatsapp_link || payload.context?.whatsapp_link || "" };
    if (source.id) {
      state.selectedSourceIntelligenceId = source.id;
      selectSourceIntelligence(source);
    }
    refs.sieImportForm.reset();
    setNotice("SIE import completed.", "success");
    await refreshSourceIntelligenceAdmin();
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleSourceIntelligenceContext(event) {
  event.preventDefault();
  if (!state.token || !refs.sieSourceForm) {
    return;
  }
  try {
    const form = new FormData(refs.sieSourceForm);
    const sourceId = parseNumber(form.get("source_id"));
    if (!sourceId) {
      throw new Error("Select a source first.");
    }
    const tags = String(form.get("tags") || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean);
    await api(`/api/v2/source-intelligence/sources/${sourceId}/context`, {
      method: "PATCH",
      auth: true,
      body: {
        network: form.get("network"),
        publication_url: form.get("publication_url"),
        publication_title: form.get("publication_title"),
        publication_text: form.get("publication_text"),
        publication_author: form.get("publication_author"),
        campaign: form.get("campaign"),
        city: form.get("city"),
        district: form.get("district"),
        property_type: form.get("property_type"),
        target_audience: form.get("target_audience"),
        format: form.get("format"),
        language: form.get("language"),
        tags,
        ai_classification: form.get("ai_classification"),
        ai_confidence: parseNumber(form.get("ai_confidence")) || 0,
        notes: form.get("notes"),
      },
    });
    setNotice("Source context updated.", "success");
    await refreshSourceIntelligenceAdmin();
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleSourceIntelligenceAnalyze() {
  if (!state.token || !refs.sieSourceForm) {
    return;
  }
  try {
    const form = new FormData(refs.sieSourceForm);
    const sourceId = parseNumber(form.get("source_id"));
    if (!sourceId) {
      throw new Error("Select a source first.");
    }
    const tags = String(form.get("tags") || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean);
    const payload = await api("/api/v2/source-intelligence/analyze", {
      method: "POST",
      auth: true,
      body: {
        source_id: sourceId,
        network: form.get("network"),
        url: form.get("publication_url"),
        title: form.get("publication_title"),
        text: form.get("publication_text"),
        author: form.get("publication_author"),
        campaign: form.get("campaign"),
        city: form.get("city"),
        district: form.get("district"),
        property_type: form.get("property_type"),
        target_audience: form.get("target_audience"),
        format: form.get("format"),
        language: form.get("language"),
        tags,
        notes: form.get("notes"),
      },
    });
    const analysis = payload.analysis || {};
    if (analysis.source) {
      selectSourceIntelligence({ ...analysis.source, whatsapp_link: analysis.context?.whatsapp_link || analysis.source.whatsapp_link || "" });
    }
    if (analysis.context) {
      fillSourceIntelligenceForm(analysis.context);
    }
    if (analysis.import?.import_key) {
      refs.sieReferenceResult.innerHTML = `
        <article class="message">
          <div class="message__meta"><strong>${escapeHtml(analysis.import.import_key)}</strong> · ${escapeHtml(analysis.import.import_status || "")}</div>
        </article>
      `;
    }
    setNotice("Source analysis completed.", "success");
    await refreshSourceIntelligenceAdmin();
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleSourceIntelligenceWhatsApp() {
  if (!state.token || !refs.sieSourceForm) {
    return;
  }
  try {
    const sourceId = parseNumber(new FormData(refs.sieSourceForm).get("source_id"));
    if (!sourceId) {
      throw new Error("Select a source first.");
    }
    const payload = await api(`/api/v2/source-intelligence/sources/${sourceId}/whatsapp-link`, {
      auth: true,
    });
    const link = payload.whatsapp_link || "";
    refs.sieLinkResult.innerHTML = `
      <article class="message">
        <div class="message__meta"><strong>WhatsApp link</strong> · ${escapeHtml(link)}</div>
      </article>
    `;
    setNotice("WhatsApp link generated.", "success");
    await refreshSourceIntelligenceAdmin();
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleSourceIntelligenceReference(event) {
  event.preventDefault();
  if (!state.token || !refs.sieReferenceForm) {
    return;
  }
  try {
    const form = new FormData(refs.sieReferenceForm);
    const payload = await api("/api/v2/source-intelligence/reference-code", {
      method: "POST",
      auth: true,
      body: { seed: form.get("seed") },
    });
    const referenceCode = payload.reference_code || "";
    refs.sieReferenceResult.innerHTML = `
      <article class="message">
        <div class="message__meta"><strong>Reference code</strong> · ${escapeHtml(referenceCode)}</div>
      </article>
    `;
    setNotice("Reference code generated.", "success");
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function refreshSecurityAdmin() {
  if (!state.token || !refs.securityAdminStats) {
    return;
  }
  try {
    const [statsPayload, rolesPayload, sessionsPayload] = await Promise.all([
      api("/api/v2/security/stats", { auth: true }),
      api("/api/v2/security/roles", { auth: true }),
      api("/api/v2/security/sessions", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    refs.securityAdminStats.innerHTML = `
      <p class="muted">${stats.users ?? 0} users · ${stats.roles ?? 0} roles · ${stats.active_sessions ?? 0} sessions · ${stats.audit_entries ?? 0} audit entries · risk ${stats.risk_alerts ?? 0}</p>
    `;
    refs.securityAuditForm?.classList.remove("hidden");
    const roles = rolesPayload.roles || [];
    refs.securityAdminList.innerHTML = roles
      .slice(0, 6)
      .map(
        (role) => `
          <article class="mini-card">
            <strong>${escapeHtml(role.name || role.role_key || "")}</strong>
            <p class="muted">${escapeHtml(role.status || "")} · ${escapeHtml(role.scope || "global")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No IAM roles loaded.</p>";
    const sessions = sessionsPayload.sessions || [];
    if (sessions.length && refs.securityAuditResults) {
      refs.securityAuditResults.innerHTML = sessions
        .slice(0, 4)
        .map(
          (session) => `
            <article class="message">
              <div class="message__meta"><strong>Session ${escapeHtml(String(session.id || ""))}</strong> · ${escapeHtml(session.status || "")}</div>
            </article>
          `,
        )
        .join("");
    }
  } catch (error) {
    refs.securityAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleSecurityAudit(event) {
  event.preventDefault();
  if (!state.token || !refs.securityAuditForm) {
    return;
  }
  const eventType = String(new FormData(refs.securityAuditForm).get("event_type") || "").trim();
  try {
    const query = eventType ? `?event_type=${encodeURIComponent(eventType)}` : "";
    const payload = await api(`/api/v2/security/audit${query}`, { auth: true });
    const entries = payload.entries || [];
    refs.securityAuditResults.innerHTML = entries
      .slice(0, 10)
      .map(
        (entry) => `
          <article class="message">
            <div class="message__meta"><strong>${escapeHtml(entry.action || entry.event_type || "event")}</strong> · ${escapeHtml(entry.outcome || "")}</div>
            <p class="muted">${escapeHtml(entry.resource_type || "")} ${escapeHtml(String(entry.resource_id || ""))}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No audit entries.</p>";
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function refreshMarketplaceAdmin() {
  if (!state.token || !refs.marketplaceAdminStats) {
    return;
  }
  try {
    const [statsPayload, providersPayload, catalogPayload] = await Promise.all([
      api("/api/v2/marketplace/stats", { auth: true }),
      api("/api/v2/marketplace/providers", { auth: true }),
      api("/api/v2/marketplace/catalog", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    refs.marketplaceAdminStats.innerHTML = `
      <p class="muted">${stats.providers ?? 0} providers · ${stats.requests ?? 0} requests · ${stats.missions ?? 0} missions · ${stats.contracts ?? 0} contracts</p>
    `;
    refs.marketplaceSearchForm?.classList.remove("hidden");
    const providers = providersPayload.providers || [];
    refs.marketplaceAdminList.innerHTML = providers
      .slice(0, 6)
      .map(
        (provider) => `
          <article class="mini-card">
            <strong>${escapeHtml(provider.headline || provider.provider_key || "")}</strong>
            <p class="muted">${escapeHtml(provider.provider_type || "")} · score ${provider.quality_score ?? "—"}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No marketplace providers yet.</p>";
    const items = catalogPayload.items || [];
    if (items.length && refs.marketplaceSearchResults) {
      refs.marketplaceSearchResults.innerHTML = items
        .slice(0, 4)
        .map(
          (item) => `
            <article class="message">
              <div class="message__meta"><strong>${escapeHtml(item.title || "")}</strong> · ${escapeHtml(item.category || "")}</div>
            </article>
          `,
        )
        .join("");
    }
  } catch (error) {
    refs.marketplaceAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleMarketplaceSearch(event) {
  event.preventDefault();
  if (!state.token || !refs.marketplaceSearchForm) {
    return;
  }
  const query = String(new FormData(refs.marketplaceSearchForm).get("query") || "").trim();
  if (!query) {
    return;
  }
  try {
    const payload = await api(`/api/v2/marketplace/catalog?category=${encodeURIComponent(query)}`, { auth: true });
    const results = payload.items || [];
    refs.marketplaceSearchResults.innerHTML = results
      .map(
        (item) => `
          <article class="message">
            <div class="message__meta"><strong>${escapeHtml(item.title || "")}</strong> · ${escapeHtml(item.category || "")}</div>
            <p>${escapeHtml(item.description || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No catalog matches.</p>";
  } catch (error) {
    refs.marketplaceSearchResults.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function refreshCrmAdmin() {
  if (!state.token || !refs.crmAdminStats) {
    return;
  }
  try {
    const [statsPayload, contactsPayload, officialPayload] = await Promise.all([
      api("/api/v2/crm/stats", { auth: true }),
      api("/api/v2/crm/contacts", { auth: true }),
      api("/api/v2/crm/official-contact", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    const official = officialPayload.contact || {};
    refs.crmAdminStats.innerHTML = `
      <p class="muted">${stats.contacts ?? 0} contacts · ${stats.leads ?? 0} leads · ${stats.customers ?? 0} customers · ${stats.campaigns ?? 0} campaigns</p>
      <p class="muted">Official: ${escapeHtml(official.phone_number || "")} · ${escapeHtml(official.whatsapp_username || "")} · ${escapeHtml(official.telegram_bot || "")}</p>
    `;
    refs.crmSearchForm?.classList.remove("hidden");
    const contacts = contactsPayload.contacts || [];
    refs.crmAdminList.innerHTML = contacts
      .slice(0, 8)
      .map(
        (contact) => `
          <article class="mini-card">
            <strong>${escapeHtml(contact.full_name)}</strong>
            <p class="muted">${escapeHtml(contact.contact_type || "")} · ${escapeHtml(contact.email || contact.phone || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No CRM contacts yet.</p>";
  } catch (error) {
    refs.crmAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleCrmSearch(event) {
  event.preventDefault();
  if (!state.token || !refs.crmSearchForm) {
    return;
  }
  const query = String(new FormData(refs.crmSearchForm).get("query") || "").trim();
  if (!query) {
    return;
  }
  try {
    const payload = await api(`/api/v2/crm/search?q=${encodeURIComponent(query)}`, { auth: true });
    const results = payload.results || [];
    refs.crmSearchResults.innerHTML = results
      .map(
        (item) => `
          <article class="message">
            <div class="message__meta"><strong>${escapeHtml(item.full_name || "")}</strong> · ${escapeHtml(item.contact_type || "")}</div>
            <p>${escapeHtml(item.email || item.phone || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No matches.</p>";
  } catch (error) {
    refs.crmSearchResults.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function refreshReiAdmin() {
  if (!state.token || !refs.reiAdminStats) {
    return;
  }
  try {
    const [statsPayload, listingsPayload, analyticsPayload] = await Promise.all([
      api("/api/v2/properties/stats", { auth: true }),
      api("/api/v2/properties/listings", { auth: true }),
      api("/api/v2/properties/analytics", { auth: true }),
    ]);
    const stats = statsPayload.stats || {};
    const analytics = analyticsPayload.analytics || {};
    refs.reiAdminStats.innerHTML = `
      <p class="muted">${stats.properties ?? 0} properties · ${stats.listings ?? 0} listings · ${stats.transactions ?? 0} transactions · trust avg ${analytics.avg_trust_score ?? "—"}</p>
    `;
    refs.reiSearchForm?.classList.remove("hidden");
    const listings = listingsPayload.listings || [];
    refs.reiAdminList.innerHTML = listings
      .slice(0, 8)
      .map(
        (listing) => `
          <article class="mini-card">
            <strong>${escapeHtml(listing.title)}</strong>
            <p class="muted">${escapeHtml(listing.status || "draft")} · AI ${listing.ai_score ?? 0}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No listings yet.</p>";
  } catch (error) {
    refs.reiAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleReiSearch(event) {
  event.preventDefault();
  if (!state.token || !refs.reiSearchForm) {
    return;
  }
  const query = String(new FormData(refs.reiSearchForm).get("query") || "").trim();
  if (!query) {
    return;
  }
  try {
    const payload = await api(`/api/v2/properties/search?q=${encodeURIComponent(query)}`, { auth: true });
    const results = payload.results || [];
    refs.reiSearchResults.innerHTML = results
      .map(
        (item) => `
          <article class="message">
            <div class="message__meta"><strong>${escapeHtml(item.title || item.listing_key || "")}</strong> · ${escapeHtml(item.status || "")}</div>
            <p>${escapeHtml(item.city || "")} · score ${item.ai_score ?? "—"}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No matches.</p>";
  } catch (error) {
    refs.reiSearchResults.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function refreshWorkflowAdmin() {
  if (!state.token || !refs.workflowAdminStats) {
    return;
  }
  try {
    const [metricsPayload, defsPayload, instancesPayload] = await Promise.all([
      api("/api/v2/workflows/metrics", { auth: true }),
      api("/api/v2/workflows/definitions", { auth: true }),
      api("/api/v2/workflows/instances?limit=8", { auth: true }),
    ]);
    const metrics = metricsPayload.metrics || {};
    refs.workflowAdminStats.innerHTML = `
      <p class="muted">${metrics.workflows ?? 0} workflows · ${metrics.instances ?? 0} instances · ${metrics.tasks ?? 0} tasks</p>
    `;
    refs.workflowMonitorForm?.classList.remove("hidden");
    const defs = defsPayload.workflows || [];
    refs.workflowAdminList.innerHTML = defs
      .slice(0, 6)
      .map(
        (row) => `
          <article class="mini-card">
            <strong>${escapeHtml(row.title)}</strong>
            <p class="muted">${escapeHtml(row.domain || "")} · ${escapeHtml(row.status || "")}</p>
          </article>
        `,
      )
      .join("") || "<p class='muted'>No automation workflows.</p>";
    const instances = instancesPayload.instances || [];
    if (instances.length && refs.workflowMonitorResults) {
      refs.workflowMonitorResults.innerHTML = instances
        .slice(0, 4)
        .map(
          (inst) => `
            <article class="message">
              <div class="message__meta"><strong>${escapeHtml(inst.workflow_key || "")}</strong> · ${escapeHtml(inst.status || "")}</div>
              <p class="muted">state ${escapeHtml(inst.current_state_key || "—")}</p>
            </article>
          `,
        )
        .join("");
    }
  } catch (error) {
    refs.workflowAdminStats.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function handleWorkflowMonitor(event) {
  event.preventDefault();
  if (!state.token) {
    return;
  }
  try {
    const payload = await api("/api/v2/workflows/monitoring", { auth: true });
    const monitoring = payload.monitoring || {};
    refs.workflowMonitorResults.innerHTML = `
      <article class="message">
        <div class="message__meta"><strong>Monitoring</strong></div>
        <p class="muted">SLA policies: ${monitoring.sla_policies ?? 0} · pending approvals: ${monitoring.pending_approvals ?? 0} · open escalations: ${monitoring.open_escalations ?? 0}</p>
      </article>
    `;
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleLogin(event) {
  event.preventDefault();
  try {
    const email = refs.loginEmail.value.trim();
    const password = refs.loginPassword.value;
    const payload = await api("/api/auth/login", {
      method: "POST",
      body: { email, password },
    });
    const token = String(payload.token || "");
    if (!token) {
      throw new Error("Login response did not include a token.");
    }
    state.token = token;
    localStorage.setItem("lawim.token", state.token);
    updateAuthShell(true);
    const resolvedRole = resolveAccessRole(payload.user?.role, payload.roles || payload.user?.roles || []);
    const resolvedJourney = journeyForRole(resolvedRole);
    traceRuntime("LOGIN_OK", {
      email: payload.user?.email || email,
      role: resolvedRole,
      journey: resolvedJourney,
    });
    traceRuntime("ROLE_RESOLVED", {
      role: resolvedRole,
      journey: resolvedJourney,
    });
    traceRuntime("DASHBOARD_SELECTED", {
      role: resolvedRole,
      journey: resolvedJourney,
    });
    await refresh({ renderJourney: false });
    applyJourney(resolvedJourney);
    refs.loginPassword.value = "";
    setNotice(`Connexion réussie pour ${payload.user?.email || email}`, "success");
  } catch (error) {
    setNotice(formatLoginError(error), "error", error.code || "");
  }
}

async function handleLogout() {
  try {
    if (state.token) {
      await api("/api/auth/logout", { method: "POST", auth: true });
    }
  } catch (error) {
    console.warn("Logout warning:", error);
  } finally {
    clearSession();
    refs.messageForm.classList.add("hidden");
    refs.conversationDetail.innerHTML = '<p class="muted">No conversation selected.</p>';
    state.selectedConversationId = null;
    setNotice("Session fermée.", "neutral");
    await refresh();
  }
}

async function handleProjectCreate(event) {
  event.preventDefault();
  if (!state.token) {
    setNotice("Sign in to create a project.", "error");
    return;
  }
  try {
    const form = new FormData(refs.projectForm);
    const payload = await api("/api/v2/projects", {
      method: "POST",
      auth: true,
      body: {
        title: form.get("title"),
        objective: form.get("objective"),
        project_type: form.get("project_type"),
        budget_min: parseNumber(form.get("budget_min")),
        budget_max: parseNumber(form.get("budget_max")),
        location_city: form.get("location_city"),
        timeline_horizon: form.get("timeline_horizon"),
        status: "active",
      },
    });
    refs.projectForm.reset();
    state.selectedProjectId = payload.project.id;
    setNotice("Project created.", "success");
    await refreshProjects();
    applyJourney("project");
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleMatchSearch(event) {
  event.preventDefault();
  try {
    const form = new FormData(refs.matchForm);
    const payload = await api("/api/matches", {
      auth: Boolean(state.token),
      query: {
        city: form.get("city"),
        budget_min: parseNumber(form.get("budget_min")),
        budget_max: parseNumber(form.get("budget_max")),
        latitude: parseNumber(form.get("latitude")),
        longitude: parseNumber(form.get("longitude")),
        limit: parseNumber(form.get("limit")),
        min_score: parseNumber(form.get("min_score")),
      },
    });
    renderMatches(payload.matches || []);
    setNotice(`Returned ${payload.matches?.length || 0} ranked matches (min score ${payload.criteria?.min_score ?? "n/a"}).`, "success");
    if (state.token) {
      await refreshNotifications();
    }
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handlePropertyCreate(event) {
  event.preventDefault();
  if (!state.token) {
    setNotice("Authenticate before creating records.", "error");
    return;
  }
  try {
    const form = new FormData(refs.propertyForm);
    await api("/api/properties", {
      method: "POST",
      auth: true,
      body: {
        title: form.get("title"),
        summary: form.get("summary"),
        city: form.get("city"),
        country: form.get("country") || "Cameroon",
        address_line: form.get("address_line"),
        region: form.get("region"),
        property_type: form.get("property_type"),
        status: form.get("status") || "draft",
        availability: form.get("availability") || "available",
        price_min: parseNumber(form.get("price_min")),
        price_max: parseNumber(form.get("price_max")),
        latitude: parseNumber(form.get("latitude")),
        longitude: parseNumber(form.get("longitude")),
        owner_organization_id: parseNumber(form.get("owner_organization_id")),
      },
    });
    refs.propertyForm.reset();
    setNotice("Property created and persisted.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleGeoLookup(event) {
  event.preventDefault();
  try {
    const form = new FormData(refs.geoForm);
    const payload = await api("/api/geo/geocode", {
      query: {
        city: form.get("city"),
        country: form.get("country"),
        address_line: form.get("address_line"),
        region: form.get("region"),
      },
    });
    const location = payload.location || {};
    const coords = location.coordinates || {};
    refs.geoResult.textContent = `${location.city}, ${location.region || "—"}, ${location.country} · ${coords.latitude}, ${coords.longitude} · provider=${payload.provider}`;
    setNotice("Geo lookup completed.", "success");
  } catch (error) {
    refs.geoResult.textContent = error.message;
    setNotice(error.message, "error");
  }
}

async function handleMediaUpload(event) {
  event.preventDefault();
  if (!state.token) {
    setNotice("Authenticate before uploading media.", "error");
    return;
  }
  try {
    const form = new FormData(refs.mediaUploadForm);
    const file = form.get("file");
    const propertyId = form.get("property_id");
    if (!file || !propertyId) {
      throw new Error("Property and file are required.");
    }
    const uploadData = new FormData();
    uploadData.append("property_id", String(propertyId));
    uploadData.append("file", file);
    uploadData.append("caption", form.get("caption") || "Uploaded media");
    uploadData.append("kind", form.get("kind") || "image");
    await apiMultipart("/api/media/upload", { auth: true, formData: uploadData });
    refs.mediaUploadForm.reset();
    setNotice("Media uploaded.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleMessageCreate(event) {
  event.preventDefault();
  if (!state.token || !state.selectedConversationId) {
    setNotice("Select a conversation and authenticate first.", "error");
    return;
  }
  try {
    const form = new FormData(refs.messageForm);
    await api(`/api/conversations/${state.selectedConversationId}/messages`, {
      method: "POST",
      auth: true,
      body: {
        body: form.get("body"),
      },
    });
    refs.messageForm.reset();
    setNotice("Reply sent.", "success");
    await selectConversation(state.selectedConversationId);
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleRegister(event) {
  event.preventDefault();
  try {
    const form = new FormData(refs.registerForm);
    const payload = await api("/api/auth/register", {
      method: "POST",
      body: {
        full_name: form.get("full_name"),
        email: form.get("email"),
        password: form.get("password"),
        role: form.get("role"),
        organization_id: parseNumber(form.get("organization_id")),
      },
    });
    const token = String(payload.token || "");
    if (!token) {
      throw new Error("Registration response did not include a token.");
    }
    state.token = token;
    localStorage.setItem("lawim.token", state.token);
    updateAuthShell(true);
    const resolvedRole = resolveAccessRole(payload.user?.role || form.get("role"));
    applyJourney(journeyForRole(resolvedRole));
    setNotice(`Registered as ${payload.user.email}`, "success");
    await refresh({ renderJourney: false });
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handlePropertySearch(event) {
  event.preventDefault();
  try {
    const form = new FormData(refs.propertySearchForm);
    const payload = await api("/api/properties", {
      query: {
        city: form.get("city"),
        region: form.get("region"),
        property_type: form.get("property_type"),
        status: form.get("status"),
        price_min: parseNumber(form.get("price_min")),
        price_max: parseNumber(form.get("price_max")),
        sort: form.get("sort") || "created_at",
        order: form.get("order") || "desc",
        page: parseNumber(form.get("page")) || 1,
        limit: parseNumber(form.get("limit")) || 10,
      },
    });
    renderProperties(payload.properties || []);
    const pagination = payload.pagination || {};
    if (refs.propertySearchMeta) {
      refs.propertySearchMeta.textContent = `Page ${pagination.page || 1}/${pagination.pages || 1} · ${pagination.total ?? payload.properties?.length ?? 0} total · sort ${pagination.sort || "created_at"} ${pagination.order || "desc"}`;
    }
    setNotice(`Found ${payload.properties?.length || 0} listings.`, "success");
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handlePublishProperty() {
  if (!state.token || !state.selectedPropertyId) {
    setNotice("Select a property and authenticate first.", "error");
    return;
  }
  try {
    const payload = await api(`/api/properties/${state.selectedPropertyId}/publish`, {
      method: "POST",
      auth: true,
      body: { version: state.selectedPropertyVersion },
    });
    state.selectedPropertyVersion = payload.property.version;
    updateSelectedPropertyLabel();
    setNotice("Property published.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleArchiveProperty() {
  if (!state.token || !state.selectedPropertyId) {
    setNotice("Select a property and authenticate first.", "error");
    return;
  }
  try {
    const payload = await api(`/api/properties/${state.selectedPropertyId}`, {
      method: "PATCH",
      auth: true,
      body: { status: "archived", version: state.selectedPropertyVersion },
    });
    state.selectedPropertyVersion = payload.property.version;
    updateSelectedPropertyLabel();
    setNotice("Property archived.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleBuyerConversation(event) {
  event.preventDefault();
  if (!state.token || !state.selectedPropertyId) {
    setNotice("Select a property and authenticate first.", "error");
    return;
  }
  try {
    const form = new FormData(refs.buyerConversationForm);
    const payload = await api("/api/conversations", {
      method: "POST",
      auth: true,
      body: {
        property_id: state.selectedPropertyId,
        subject: form.get("subject"),
        initial_message: form.get("initial_message"),
      },
    });
    refs.buyerConversationForm.reset();
    state.selectedConversationId = payload.conversation.id;
    setNotice("Conversation opened.", "success");
    await refresh();
    await selectConversation(payload.conversation.id);
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleNegotiationUpdate(event) {
  event.preventDefault();
  if (!state.token || !state.selectedConversationId) {
    setNotice("Select a conversation first.", "error");
    return;
  }
  try {
    const form = new FormData(refs.negotiationForm);
    const payload = await api(`/api/conversations/${state.selectedConversationId}`, {
      method: "PATCH",
      auth: true,
      body: { negotiation_stage: form.get("negotiation_stage") },
    });
    renderConversationDetail(payload.conversation);
    setNotice(`Negotiation stage updated to ${payload.conversation.negotiation_stage}.`, "success");
    await refresh();
    await refreshNotifications();
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleNotificationFilter(event) {
  event.preventDefault();
  try {
    await refreshNotifications();
    setNotice("Notification filter applied.", "success");
  } catch (error) {
    setNotice(error.message, "error", error.code || "");
  }
}

async function handleAdminOrgCreate(event) {
  event.preventDefault();
  if (!state.token) {
    setNotice("Authenticate as admin first.", "error");
    return;
  }
  try {
    const form = new FormData(refs.adminOrgForm);
    await api("/api/organizations", {
      method: "POST",
      auth: true,
      body: { name: form.get("name"), slug: form.get("slug"), kind: "agency", city: "Douala" },
    });
    refs.adminOrgForm.reset();
    setNotice("Organization created.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

async function handleAdminUserCreate(event) {
  event.preventDefault();
  if (!state.token) {
    setNotice("Authenticate as admin first.", "error");
    return;
  }
  try {
    const form = new FormData(refs.adminUserForm);
    await api("/api/users", {
      method: "POST",
      auth: true,
      body: {
        email: form.get("email"),
        full_name: form.get("full_name"),
        role: "agent",
        password: form.get("password") || "",
        organization_id: parseNumber(form.get("organization_id")),
      },
    });
    refs.adminUserForm.reset();
    setNotice("Staff user created.", "success");
    await refresh();
  } catch (error) {
    setNotice(error.message, "error");
  }
}

function bindEvents() {
  refs.loginForm.addEventListener("submit", handleLogin);
  refs.logoutButton.addEventListener("click", handleLogout);
  refs.registerForm?.addEventListener("submit", handleRegister);
  refs.projectForm?.addEventListener("submit", handleProjectCreate);
  refs.assistantForm?.addEventListener("submit", handleAssistantChat);
  refs.knowledgeSearchForm?.addEventListener("submit", handleKnowledgeSearch);
  refs.reiSearchForm?.addEventListener("submit", handleReiSearch);
  refs.crmSearchForm?.addEventListener("submit", handleCrmSearch);
  refs.marketplaceSearchForm?.addEventListener("submit", handleMarketplaceSearch);
  refs.sieImportForm?.addEventListener("submit", handleSourceIntelligenceImport);
  refs.sieSourceForm?.addEventListener("submit", handleSourceIntelligenceContext);
  refs.sieReferenceForm?.addEventListener("submit", handleSourceIntelligenceReference);
  refs.sieAnalyzeButton?.addEventListener("click", handleSourceIntelligenceAnalyze);
  refs.sieWhatsappButton?.addEventListener("click", handleSourceIntelligenceWhatsApp);
  refs.securityAuditForm?.addEventListener("submit", handleSecurityAudit);
  refs.workflowMonitorForm?.addEventListener("submit", handleWorkflowMonitor);
  refs.propertySearchForm?.addEventListener("submit", handlePropertySearch);
  refs.matchForm.addEventListener("submit", handleMatchSearch);
  refs.propertyForm.addEventListener("submit", handlePropertyCreate);
  refs.geoForm.addEventListener("submit", handleGeoLookup);
  refs.mediaUploadForm.addEventListener("submit", handleMediaUpload);
  refs.messageForm.addEventListener("submit", handleMessageCreate);
  refs.buyerConversationForm?.addEventListener("submit", handleBuyerConversation);
  refs.negotiationForm?.addEventListener("submit", handleNegotiationUpdate);
  refs.notificationFilterForm?.addEventListener("submit", handleNotificationFilter);
  refs.adminOrgForm?.addEventListener("submit", handleAdminOrgCreate);
  refs.adminUserForm?.addEventListener("submit", handleAdminUserCreate);
  refs.publishPropertyButton?.addEventListener("click", handlePublishProperty);
  refs.archivePropertyButton?.addEventListener("click", handleArchiveProperty);
  refs.languageSelect?.addEventListener("change", (event) => {
    setLanguage(String(event.target.value || "fr"));
  });
  refs.statsPeriodSelect?.addEventListener("change", (event) => {
    state.statsPeriod = String(event.target.value || "today");
    localStorage.setItem("lawim.stats.period", state.statsPeriod);
    if (state.bootstrap?.current_user) {
      renderRoleCockpit(state.bootstrap.current_user, state.bootstrap);
    }
  });
  refs.journeyNav?.querySelectorAll("[data-journey]").forEach((button) => {
    button.addEventListener("click", () => applyJourney(button.getAttribute("data-journey")));
  });
  if (refs.markNotificationsReadButton) {
    refs.markNotificationsReadButton.addEventListener("click", markAllNotificationsRead);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  cacheRefs();
  bindEvents();
  updateAuthShell(Boolean(state.token));
  setLanguage(state.language);
  applyJourney(state.activeJourney);
  updateSelectedPropertyLabel();
  await refresh();
});
